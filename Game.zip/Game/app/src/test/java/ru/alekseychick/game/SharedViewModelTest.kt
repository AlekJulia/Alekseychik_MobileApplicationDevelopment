package ru.alekseychick.game

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

class SharedViewModelTest {

    // проверка функции selectLevel
    @get:Rule
    val rule = InstantTaskExecutorRule() // чтобы LiveData работала синхронно при тестировании

    @Test
    fun testSelectLevel() {
        val vm = SharedViewModel() // новый экземпляр SharedViewModel, который будет тестироваться
        val level = Level(100, "Test level", "Легкий")
        vm.selectLevel(level) // передаём созданный объект level

        // проверяем что LiveData содержит тот же объект, который мы передали
        assertEquals(level, vm.selectedLevel.value)
    }
}