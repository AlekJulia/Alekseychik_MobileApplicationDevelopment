package ru.alekseychick.game

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

// операции для работы с базой данных
@Dao
interface ScoreDao {

    // вставить новый рекорд
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: ScoreRecord): Long

    // получить все рекорды, отсортированные по убыванию очков
    @Query("SELECT * FROM score_records ORDER BY score DESC, date DESC")
    fun getAllSortedByScoreDesc(): Flow<List<ScoreRecord>>

    // очистить таблицу
    @Query("DELETE FROM score_records")
    suspend fun clearAll()
}