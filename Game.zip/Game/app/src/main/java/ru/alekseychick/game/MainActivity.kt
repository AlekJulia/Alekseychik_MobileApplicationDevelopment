package ru.alekseychick.game

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit

class MainActivity : AppCompatActivity() {

    private lateinit var fragmentContainer: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // кнопка начать игру
        val btnStart: Button = findViewById(R.id.btnStart)
        btnStart.setOnClickListener {
            Toast.makeText(this, "Игра начинается!", Toast.LENGTH_SHORT).show()
            openFragment(GameFragment())
        }

        // кнопки для открытия фрагментов
        val btnLevels: Button = findViewById(R.id.btnLevels)
        val btnSettings: Button = findViewById(R.id.btnSettings)

        // кнопка для таблицы рекордов
        val btnLeaderboard: Button = findViewById(R.id.btnLeaderboard)
        btnLeaderboard.setOnClickListener { openFragment(LeaderboardFragment()) }

        fragmentContainer = findViewById(R.id.fragmentContainer)

        btnLevels.setOnClickListener {
            openFragment(LevelsFragment())
        }

        btnSettings.setOnClickListener {
            openFragment(SettingsFragment())
        }
    }

    // метод для открытия фрагмента в контейнере
    private fun openFragment(fragment: androidx.fragment.app.Fragment) {
        // контейнер становится видимым
        fragmentContainer.visibility = View.VISIBLE

        // открытие фрагмента и его добавление в back stack, чтобы можно было вернуться
        supportFragmentManager.commit {
            replace(R.id.fragmentContainer, fragment)
            addToBackStack(null)
        }
    }
}