package ru.alekseychick.game

import android.content.Context
import android.media.MediaPlayer
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider

// игровой фрагмент
class GameFragment : Fragment(), GameView.GameListener {

    private lateinit var gameView: GameView
    private lateinit var tvScoreTop: TextView // текст счёта
    private lateinit var btnExit: Button // кнопка выхода
    private var mediaPlayer: MediaPlayer? = null // проигрыватель музыки

    private lateinit var leaderboardViewModel: LeaderboardViewModel // для рекордов

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // создания контейнера для занятия всего экрана
        val root = inflater.inflate(R.layout.fragment_game, container, false)
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // привязка к активити, чтобы данные сохранялись между фрагментами
        leaderboardViewModel = ViewModelProvider(requireActivity(), ViewModelProvider.AndroidViewModelFactory.getInstance(requireActivity().application)).get(LeaderboardViewModel::class.java)

        // нахождение view элементов по id
        tvScoreTop = view.findViewById(R.id.tvGameScore)
        btnExit = view.findViewById(R.id.btnExitGame)

        // програмное создание GameView для установки размера на весь экран
        val frame: FrameLayout = view.findViewById(R.id.gameHost)
        gameView = GameView(requireContext())
        gameView.layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        gameView.listener = this
        frame.addView(gameView)

        // старт/стоп фоновой музыки согласно настройке (считывание из SharedPreferences)
        val prefs = requireActivity().getSharedPreferences("game_prefs", Context.MODE_PRIVATE)
        val musicOn = prefs.getBoolean("pref_music", true)
        if (musicOn) { // если настроки включены, создаётся MediaPlayer, который зацикливает музыку
            mediaPlayer = MediaPlayer.create(requireContext(), R.raw.bg_music)
            mediaPlayer?.isLooping = true
            mediaPlayer?.start()
        }

        // слушатель выхода
        btnExit.setOnClickListener {
            endGameAndSave()
        }

        // скрытие всех кнопок из меню
        (activity as? MainActivity)?.let { act ->
            act.findViewById<View>(R.id.tvTitle)?.visibility = View.GONE
            act.findViewById<View>(R.id.btnLevels)?.visibility = View.GONE
            act.findViewById<View>(R.id.btnSettings)?.visibility = View.GONE
            act.findViewById<View>(R.id.btnLeaderboard)?.visibility = View.GONE
            act.findViewById<View>(R.id.btnStart)?.visibility = View.GONE
        }

        // запуск игры, счётчик очков = 0
        updateTopScore(0)
        gameView.startGame()
    }

    // отчистка ресурсов, возвращение к начальному меню
    override fun onDestroyView() {
        super.onDestroyView() // удаляем фоновую музыку
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        gameView.stopGame()

        // возвращение кнопок из стартового меню
        (activity as? MainActivity)?.let { act ->
            act.findViewById<View>(R.id.tvTitle)?.visibility = View.VISIBLE
            act.findViewById<View>(R.id.btnLevels)?.visibility = View.VISIBLE
            act.findViewById<View>(R.id.btnSettings)?.visibility = View.VISIBLE
            act.findViewById<View>(R.id.btnLeaderboard)?.visibility = View.VISIBLE
            act.findViewById<View>(R.id.btnStart)?.visibility = View.VISIBLE
        }
    }

    // GameListener
    override fun onScoreChanged(score: Int) {
        updateTopScore(score)
        // обновление счёта
        val it = android.content.Intent(requireContext(), GameForegroundService::class.java)
        it.putExtra("score", score)
        it.action = GameForegroundService.ACTION_UPDATE
               requireContext().startService(it)
    }

    // окончание игры
    override fun onGameOver(finalScore: Int) {
        // музыка останавливается
        mediaPlayer?.pause()
        // показывается диалог об окончании игры
        val dlg = GameOverDialogFragment.newInstance(finalScore)
        dlg.show(parentFragmentManager, "game_over")
    }

    // обновление счёта на экране
    private fun updateTopScore(score: Int) {
        tvScoreTop.text = "Счет: $score"
    }

    // завершение игры с сохранением
    private fun endGameAndSave() { // получение имя игрока из настроек
        val playerName = requireActivity().getSharedPreferences("game_prefs", Context.MODE_PRIVATE)
            .getString("pref_player_name", "Игрок") ?: "Игрок"
        val finalScore = gameView.currentScore
        leaderboardViewModel.addSampleRecord(playerName, finalScore)
        // вернуться назад на начальный экран
        parentFragmentManager.popBackStack()
    }
}
