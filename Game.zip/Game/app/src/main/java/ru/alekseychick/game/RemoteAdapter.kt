package ru.alekseychick.game

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import ru.alekseychick.game.R
import ru.alekseychick.game.RemoteRecord
import ru.alekseychick.game.toDisplayDate

// адаптер для работы с мировыми рекордами (использует серверные данные)
class RemoteAdapter(private var items: List<RemoteRecord> = emptyList()) :
    RecyclerView.Adapter<RemoteAdapter.RemoteVH>() {

    inner class RemoteVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvPlayer: TextView = itemView.findViewById(R.id.tvRemotePlayer)
        val tvScore: TextView = itemView.findViewById(R.id.tvRemoteScore)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RemoteVH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_remote_record, parent, false)
        return RemoteVH(view)
    }

    override fun onBindViewHolder(holder: RemoteVH, position: Int) {
        val r = items[position]
        holder.tvPlayer.text = r.playerName
        holder.tvScore.text = r.score.toString()
    }

    override fun getItemCount(): Int = items.size

    fun submitList(newItems: List<RemoteRecord>) {
        items = newItems
        notifyDataSetChanged()
    }
}