package ru.alekseychick.game

import android.content.Context
import android.graphics.*
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.res.ResourcesCompat
import kotlinx.coroutines.*
import kotlin.math.hypot
import kotlin.random.Random
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModel
import kotlin.math.abs

// создание игрового поля
class GameView @JvmOverloads constructor( //  @JvmOverloads создание view из xml
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    // слушатель для событий игры (изменение счёта, окончине игры)
    interface GameListener {
        fun onScoreChanged(score: Int)
        fun onGameOver(finalScore: Int)
    }

    var listener: GameListener? = null

    // ресурсы графики
    private val mouseBitmapOrig = BitmapFactory.decodeResource(resources, R.drawable.mouse)
    private val cheeseBitmapOrig = BitmapFactory.decodeResource(resources, R.drawable.cheese)
    private val catBitmapOrig = BitmapFactory.decodeResource(resources, R.drawable.cat)

    // размеры спрайтов в пикселях
    private val mouseSizePx = dpToPx(70)
    private val cheeseSizePx = dpToPx(64)
    private val catSizePx = dpToPx(140)

    // для сохранения масштаба изображения
    private fun scaleBitmapPreserveRatio(src: Bitmap, targetSize: Int): Bitmap {
        val ratio = src.width.toFloat() / src.height.toFloat()
        val newWidth: Int
        val newHeight: Int

        if (ratio > 1f) { // горизонтальное изображение
            newWidth = targetSize
            newHeight = (targetSize / ratio).toInt()
        } else { // вертикальное или квадратное
            newHeight = targetSize
            newWidth = (targetSize * ratio).toInt()
        }

        return Bitmap.createScaledBitmap(src, newWidth, newHeight, true)
    }
    private val mouseBitmap = scaleBitmapPreserveRatio(mouseBitmapOrig, mouseSizePx)
    private val cheeseBitmap = scaleBitmapPreserveRatio(cheeseBitmapOrig, cheeseSizePx)
    private val catBitmap = scaleBitmapPreserveRatio(catBitmapOrig, catSizePx)

    // игровой объект мышь (используеты класс Mouse)
    private val mouse = Mouse(name = "Mouser", speed = 100)
    // координаты на экране
    private var mouseX = 0f
    private var mouseY = 0f

    // список сыров и котов
    private val cheeses = mutableListOf<Cheese>()
    private val cats = mutableListOf<Cat>()

    // игровые параметры
    private var score = 0 // счёт
    var currentScore: Int = 0
        private set

    private var running = false // флаг активности игры

    // корутина для асинхронных задач
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // SoundPool для эффектов
    private var soundPool: SoundPool? = null // для быстрого воспроизведения звуковых эффктов
    private var soundEatId: Int = 0 // ID звука поедания сыра

    init {
        // инициализация звуков (для игр, звуковые эффекты)
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        soundPool = SoundPool.Builder().setAudioAttributes(attrs).setMaxStreams(3).build() // максимум три звука одновременно
        soundEatId = soundPool!!.load(context, R.raw.eat_cheese, 1) // загрузка звукового эффекта в soundpool

        // задание значений стартовой позиции
        mouseX = 300f
        mouseY = 300f
    }

    // запуск игры
    fun startGame() {
        if (running) return

        // ждём, пока View будет измерен
        if (width == 0 || height == 0) {
            post { startGame() }
            return
        }

        running = true
        score = 0
        currentScore = 0
        cheeses.clear()
        cats.clear()

        // инициализация котов в зависимости от уровня сложности
        // получаем ViewModel чтобы посмотреть выбранный уровень
        val sharedLevel = (context as? androidx.fragment.app.FragmentActivity)?.let { act ->
            ViewModelProvider(act, ViewModelProvider.AndroidViewModelFactory.getInstance(act.application)).get(SharedViewModel::class.java)
        }
        // Меняем парамерт уровня сложности в зависимости от текстового значения
        val level = sharedLevel?.selectedLevel?.value
        val difficulty = when (level?.difficulty) {
            "Легкий" -> 1
            "Средний" -> 2
            "Сложный" -> 3
            else -> 1
        }
        // количество котов и их скорость (зависит от сложности)
        val catsCount = when (difficulty) {
            1 -> 2
            2 -> 3
            3 -> 4
            else -> 1
        }
        val catBaseSpeed = 5 + difficulty * 2// 3..5

        // генерация котов
        repeat(catsCount) {
            var x: Float
            var y: Float
            do {
                x = Random.nextInt(0, width - catSizePx).toFloat()
                y = Random.nextInt(0, height - catSizePx).toFloat()
            } while (distance(x, y, mouseX, mouseY) < 500f) // чтобы не рядом с мышью

            // направление и скорость, разнообразие движения
            val angle = Random.nextDouble(0.0, 2 * Math.PI)
            val speed = catBaseSpeed + Random.nextDouble(0.0, 3.0)
            val vx = (Math.cos(angle) * speed).toFloat()
            val vy = (Math.sin(angle) * speed).toFloat()

            cats.add(Cat(x, y, vx, vy, catSizePx))
        }

        // корутина игрового цикла (параллельные задачи генерации сыра и игрового цикла)
        scope.launch {
            spawnCheesesLoop()
        }

        scope.launch {
            gameLoop()
        }
    }

    // чтобы мышь была по центру
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (mouseX == 0f && mouseY == 0f) {
            mouseX = w / 2f - mouseSizePx / 2f
            mouseY = h / 2f - mouseSizePx / 2f
        }
    }

    // функция конца игры
    fun stopGame() {
        running = false
        scope.coroutineContext.cancelChildren()
        scope.cancel()
        soundPool?.release()
        soundPool = null
    }

    // функция генерации сыра
    private suspend fun spawnCheesesLoop() {
        while (running) {
            delay(Random.nextLong(800, 2500))
            if (!running) break
            val nx = Random.nextInt(50, (width - 50).coerceAtLeast(50)).toFloat()
            val ny = Random.nextInt(50, (height - 50).coerceAtLeast(50)).toFloat()
            val ch = Cheese(nx, ny, cheeseSizePx)
            cheeses.add(ch)
            // исчезновение через некоторое время (если не собран)
            scope.launch {
                delay(7000)
                cheeses.remove(ch)
            }
        }
    }

    // основной цикл
    private suspend fun gameLoop() {
        val frameDelay = 16L // количество кадров 60 fps
        while (running) {
            updatePhysics()  // обновление состояния
            invalidate() // перерисовка экрана
            delay(frameDelay)
        }
    }

    // физика и коллизии
    private fun updatePhysics() {
        // движение котов
        for (cat in cats) {
            cat.x += cat.vx
            cat.y += cat.vy

            // изменение направления котов раз в секунду
            if (Random.nextInt(0, 20) == 0) { // 1 из 60 кадров (~раз в секунду)
                val angleChange = Random.nextDouble(-1.5, 1.5) // в радианах
                val speed = hypot(cat.vx.toDouble(), cat.vy.toDouble())
                val angle = Math.atan2(cat.vy.toDouble(), cat.vx.toDouble()) + angleChange
                cat.vx = (Math.cos(angle) * speed).toFloat()
                cat.vy = (Math.sin(angle) * speed).toFloat()
            }

            // Левая и правая границы
            if (cat.x < 0) {
                cat.x = 0f
                cat.vx = abs(cat.vx)
            } else if (cat.x + cat.size > width) {
                cat.x = (width - cat.size).toFloat()
                cat.vx = -abs(cat.vx)
            }

            // Верхняя и нижняя границы
            if (cat.y < 0) {
                cat.y = 0f
                cat.vy = abs(cat.vy)
            } else if (cat.y + cat.size > height) {
                cat.y = (height - cat.size).toFloat()
                cat.vy = -abs(cat.vy)
            }

        }

        // проверка столкновений c сыром (круг)
        val it = cheeses.toList()
        for (ch in it) {
            if (distance(mouseX + mouseSizePx/2f, mouseY + mouseSizePx/2f, ch.x + ch.size/2f, ch.y + ch.size/2f) < (mouseSizePx/2f + ch.size/2f)) {
                // съедено
                cheeses.remove(ch)
                score += 1
                currentScore = score
                listener?.onScoreChanged(score)
                soundPool?.play(soundEatId, 1f, 1f, 1, 0, 1f)
            }
        }

        // проверка столкновений c сыром
        fun isCollidingRect(
            x1: Float, y1: Float, size1: Int,
            x2: Float, y2: Float, size2: Int
        ): Boolean {
            return !(x1 + size1 < x2 || x1 > x2 + size2 ||
                    y1 + size1 < y2 || y1 > y2 + size2)
        }

        // проверка столкновений с котом  (прямоугольник)
        for (cat in cats) {
            val catHitboxSize = cat.size / 2  // хитбокс в 2 раза меньше
            val catHitboxX = cat.x + cat.size / 4  // центрируем хитбокс
            val catHitboxY = cat.y + cat.size / 4

            if (isCollidingRect(mouseX, mouseY, mouseSizePx, catHitboxX, catHitboxY, catHitboxSize)) {
                running = false
                listener?.onGameOver(score)
                break
            }
        }
    }

    // отрисовка игрового экрана
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // рисует сыры
        for (c in cheeses) {
            canvas.drawBitmap(cheeseBitmap, c.x, c.y, null)
        }

        // рисует котов
        for (cat in cats) {
            canvas.drawBitmap(catBitmap, cat.x, cat.y, null)
        }

        // рисует мышь
        canvas.drawBitmap(mouseBitmap, mouseX, mouseY, null)
    }

    // управление касанием пальца
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event == null) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                // мышь следует за касанием, плавно интерполируем
                val tx = event.x - mouseSizePx/2f
                val ty = event.y - mouseSizePx/2f
                // перемещаем с ограничением скорости (используется mouse.speed)
                val dx = tx - mouseX
                val dy = ty - mouseY
                val dist = hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (dist > 0) {
                    val maxStep = mouse.speed.toFloat()
                    val step = if (dist > maxStep) maxStep else dist
                    mouseX += dx / dist * step
                    mouseY += dy / dist * step
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
        }
        return super.onTouchEvent(event)
    }

    // конвертация единиц времени
    private fun dpToPx(dp: Int): Int {
        val density = resources.displayMetrics.density
        return (dp * density).toInt()
    }

    // расчёт расстояния между точками
    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        return hypot((x1 - x2).toDouble(), (y1 - y2).toDouble()).toFloat()
    }
}
