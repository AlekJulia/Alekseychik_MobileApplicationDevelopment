package ru.alekseychick.game

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

// фрагмент со списком уровней
class LevelsFragment : Fragment() {

    private lateinit var sharedViewModel: SharedViewModel

    // список уровней
    private val sampleLevels = listOf(
        Level(1, "Уровень 1", "Легкий"),
        Level(2, "Уровень 2", "Средний"),
        Level(3, "Уровень 3", "Сложный"),
    )

    // создание ui для фрагмента
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? { // на основе fragment_levels.xml
        return inflater.inflate(R.layout.fragment_levels, container, false)
    }

    // инициализация ui элементов
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // получение общего ViewModel через активность (чтобы он был один на всё activity)
        sharedViewModel = ViewModelProvider(requireActivity()).get(SharedViewModel::class.java)

        val rv: RecyclerView = view.findViewById(R.id.rvLevels)
        rv.layoutManager = LinearLayoutManager(requireContext())

        val adapter = LevelsAdapter(sampleLevels) { level ->
            // при выборе уровня сохраняем в ViewModel
            sharedViewModel.selectLevel(level)

            // сообщение пользователю об уровне
            Toast.makeText(requireContext(), "Выбран ${level.name} (${level.difficulty})", Toast.LENGTH_SHORT).show()
        }

        rv.adapter = adapter
    }
}