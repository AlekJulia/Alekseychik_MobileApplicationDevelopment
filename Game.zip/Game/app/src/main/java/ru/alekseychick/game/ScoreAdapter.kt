package ru.alekseychick.game

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import ru.alekseychick.game.R
import ru.alekseychick.game.ScoreRecord
import ru.alekseychick.game.toDisplayDate

// адаптер для RecyclerView рекордов (использует локальные данные)
class ScoreAdapter(private var items: List<ScoreRecord> = emptyList()) : // берётся список рекордов бд
    RecyclerView.Adapter<ScoreAdapter.ScoreVH>() {

    // класс рекорда ViewHolder
    inner class ScoreVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tvPlayerName)
        val tvScoreDate: TextView = itemView.findViewById(R.id.tvScoreAndDate)
    }

    // создание viewholder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScoreVH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_score, parent, false)
        return ScoreVH(view)
    }

    // привязка данных к view
    override fun onBindViewHolder(holder: ScoreVH, position: Int) {
        val r = items[position]
        holder.tvName.text = r.playerName
        holder.tvScoreDate.text = "${r.score}     ${r.date.toDisplayDate()}"
    }

    // количество получишвихся элементов
    override fun getItemCount(): Int = items.size

    // обновления данных адаптера
    fun submitList(newItems: List<ScoreRecord>) {
        items = newItems
        notifyDataSetChanged()
    }
}