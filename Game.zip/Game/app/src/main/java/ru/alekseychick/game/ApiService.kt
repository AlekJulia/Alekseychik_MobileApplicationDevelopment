package ru.alekseychick.game

import retrofit2.http.GET


// определение http запроса к серверу
interface ApiService {
    @GET("/posts") // делает запрос по адресу /posts, чтобы получить данные с сервера
    // функция корутина, возвращает список объектов
    suspend fun getPosts(): List<PostDto>
}

// DTO для jsonplaceholder posts
data class PostDto( // шаблон для данных, которые получаем с сервера
    val userId: Int,
    val id: Int,
    val title: String,
    val body: String
)