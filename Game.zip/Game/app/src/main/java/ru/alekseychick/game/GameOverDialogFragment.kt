package ru.alekseychick.game

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModel

// диалоговое окно окончания игры (диалоговое окно)
class GameOverDialogFragment : DialogFragment() {

    companion object {
        private const val ARG_SCORE = "arg_score"
        fun newInstance(score: Int): GameOverDialogFragment {
            val f = GameOverDialogFragment()
            val b = Bundle()
            b.putInt(ARG_SCORE, score)
            f.arguments = b
            return f
        }
    }

    // создание диалога, считываются счёт и имя игрока
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val score = arguments?.getInt(ARG_SCORE) ?: 0
        val prefs = requireActivity().getSharedPreferences("game_prefs", Context.MODE_PRIVATE)
        val playerName = prefs.getString("pref_player_name", "Игрок") ?: "Игрок"

        return AlertDialog.Builder(requireContext())
            .setTitle("Игра окончена")
            .setMessage("Ваш счет: $score")
            .setPositiveButton("Сохранить") { _, _ ->
                // сохраняем рекорд
                val vm = androidx.lifecycle.ViewModelProvider(requireActivity(), ViewModelProvider.AndroidViewModelFactory.getInstance(requireActivity().application)).get(LeaderboardViewModel::class.java)
                vm.addSampleRecord(playerName, score)
                dismiss()
                parentFragmentManager.popBackStack()
            }
            .setNegativeButton("Отмена") { _, _ ->
                dismiss()
                parentFragmentManager.popBackStack()
            }
            .create()
    }
}
