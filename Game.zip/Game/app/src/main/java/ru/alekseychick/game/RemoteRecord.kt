package ru.alekseychick.game

// модель полученная с сервера, которая будет использоваться в приложении

data class RemoteRecord(
    val id: Int,
    val playerName: String,
    val score: Int,
    val date: String //  "yyyy-MM-dd"
)