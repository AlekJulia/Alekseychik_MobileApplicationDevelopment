package ru.alekseychick.game

// форматирование даты строки yyyy-MM-dd в dd.MM.yyyy
fun String.toDisplayDate(): String {
    // ожидание вход вида yyyy-MM-dd
    return try {
        val parts = this.split("-")
        if (parts.size >= 3) {
            val year = parts[0]
            val month = parts[1]
            val day = parts[2]
            "$day.$month.$year"
        } else {
            // если формат не тот, возвращаем исходную строку
            this
        }
    } catch (e: Exception) {
        this
    }
}