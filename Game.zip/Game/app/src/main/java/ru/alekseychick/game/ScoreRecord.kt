package ru.alekseychick.game

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*

// Таблица

// Entity для таблицы рекордов локальной БД
@Entity(tableName = "score_records") // указываем название таблицы
data class ScoreRecord(
    @PrimaryKey(autoGenerate = true) // первичный ключ
    val id: Int = 0,

    val playerName: String,
    val score: Int,

    // "yyyy-MM-dd"
    val date: String
)