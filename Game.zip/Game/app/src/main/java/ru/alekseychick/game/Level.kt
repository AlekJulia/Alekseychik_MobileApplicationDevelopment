package ru.alekseychick.game

// Модель данных уровня игры
data class Level(
    val id: Int,            // уникальный идентификатор уровня
    val name: String,       // название уровня
    val difficulty: String  // сложность: легкий, средний, сложный
)