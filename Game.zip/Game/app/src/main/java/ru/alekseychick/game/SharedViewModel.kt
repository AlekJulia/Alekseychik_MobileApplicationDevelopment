package ru.alekseychick.game

import androidx.lifecycle.LiveData // класс, который хранит данные и следит за их изменением
import androidx.lifecycle.MutableLiveData // класс, который позволяет менять данные
import androidx.lifecycle.ViewModel // класс для хранения данных из интерфейса

// ViewModel для обмена выбранным уровнем между фрагментами
class SharedViewModel : ViewModel() {

    // внутренний MutableLiveData для выбранного уровня
    private val _selectedLevel = MutableLiveData<Level?>() // создаём элемент MutableLiveData который будет хранить даннные уровня Level

    // внешний LiveData для наблюдения из фрагментов
    val selectedLevel: LiveData<Level?> = _selectedLevel

    // метод для установки выбранного уровня
    fun selectLevel(level: Level) {
        _selectedLevel.value = level
    }

    // метод для сброса выбранного уровня
    fun clearSelection() {
        _selectedLevel.value = null
    }
}