package ru.alekseychick.game

import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.hasDescendant
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LevelsFragmentTest {
    // проверка, что при нажатии на кнопку "уровни" открывается список уровней и на элемент списка можно кликнуть
    @Test
    fun levelsListIsDisplayed_and_itemClickable() {
        // запуск MainActivity
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            // нажатие на кнопку уровни
            onView(withId(R.id.btnLevels)).perform(click())

            // кликаем на элемент с уровнем
            onView(withId(R.id.rvLevels))
                .perform(RecyclerViewActions.actionOnItem<LevelsAdapter.LevelViewHolder>(
                    hasDescendant(withText("Уровень 2")), click()))
        }
    }
}