package ru.alekseychick.alekseychik_ulia_lab24

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var sunMoonView: SunMoonView
    private lateinit var startBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // layout ниже

        sunMoonView = findViewById(R.id.sunMoonView)
        startBtn = findViewById(R.id.btnStart)

        startBtn.setOnClickListener {
            // Запускаем анимацию: солнце идёт по дуге, затем ночь и звезды
            sunMoonView.startAnimation()
        }
    }

    override fun onPause() {
        super.onPause()
        // Остановим анимации, чтобы не бегали в фоне
        sunMoonView.stopAnimation()
    }
}