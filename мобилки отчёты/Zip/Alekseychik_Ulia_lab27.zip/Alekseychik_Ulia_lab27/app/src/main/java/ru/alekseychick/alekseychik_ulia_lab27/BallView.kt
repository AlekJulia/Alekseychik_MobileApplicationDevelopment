package ru.alekseychick.alekseychik_ulia_lab27


import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class BallView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val ballPaint = Paint().apply {
        color = Color.RED
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val borderPaint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 4f
        isAntiAlias = true
    }

    // Параметры шарика
    var ballX = 0f
    var ballY = 0f
    var ballSpeedX = 0f
    var ballSpeedY = 0f
    var ballRadius = 40f

    // Коэффициенты для настройки физики
    private val gravityScale = 0.5f
    private val damping = 0.9f // Затухание при отскоке
    private val maxSpeed = 50f

    init {
        // Инициализация в основном потоке после измерения размеров
        post {
            resetBallPosition()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        resetBallPosition()
    }

    private fun resetBallPosition() {
        ballX = width / 2f
        ballY = height / 2f
        ballSpeedX = 0f
        ballSpeedY = 0f
    }

    fun updatePhysics(gravityX: Float, gravityY: Float) {
        // Применяем гравитацию к скорости
        // В Android ось Y направлена вниз, поэтому добавляем гравитацию
        ballSpeedX += gravityX * gravityScale
        ballSpeedY += gravityY * gravityScale

        // Ограничиваем максимальную скорость
        ballSpeedX = ballSpeedX.coerceIn(-maxSpeed, maxSpeed)
        ballSpeedY = ballSpeedY.coerceIn(-maxSpeed, maxSpeed)

        // Обновляем позицию
        ballX += ballSpeedX
        ballY += ballSpeedY

        // Проверяем столкновения с границами
        checkBoundaryCollisions()
    }

    private fun checkBoundaryCollisions() {
        val leftBound = ballRadius
        val rightBound = width - ballRadius
        val topBound = ballRadius
        val bottomBound = height - ballRadius

        // Столкновение с левой или правой границей
        if (ballX < leftBound) {
            ballX = leftBound
            ballSpeedX = -ballSpeedX * damping
        } else if (ballX > rightBound) {
            ballX = rightBound
            ballSpeedX = -ballSpeedX * damping
        }

        // Столкновение с верхней или нижней границей
        if (ballY < topBound) {
            ballY = topBound
            ballSpeedY = -ballSpeedY * damping
        } else if (ballY > bottomBound) {
            ballY = bottomBound
            ballSpeedY = -ballSpeedY * damping
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Рисуем границы
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), borderPaint)

        // Рисуем шарик
        canvas.drawCircle(ballX, ballY, ballRadius, ballPaint)
    }
}