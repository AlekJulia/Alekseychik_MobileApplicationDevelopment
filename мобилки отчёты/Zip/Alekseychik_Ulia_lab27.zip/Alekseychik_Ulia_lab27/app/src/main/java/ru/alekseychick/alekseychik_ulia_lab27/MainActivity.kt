package ru.alekseychick.alekseychik_ulia_lab27


import android.content.Context
import android.content.pm.ActivityInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var gravitySensor: Sensor? = null // Изменено на nullable
    private lateinit var ballView: BallView
    private lateinit var coordinatesTextView: TextView
    private lateinit var gravityTextView: TextView

    private var gravityX = 0f
    private var gravityY = 0f
    private var gravityZ = 0f

    private val updateHandler = Handler(Looper.getMainLooper())
    private val updateInterval = 16L // ~60 FPS

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Фиксируем ориентацию портретной
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        initializeViews()
        initializeSensors()
        startGameLoop()
    }

    private fun initializeViews() {
        ballView = findViewById(R.id.ballView)
        coordinatesTextView = findViewById(R.id.coordinatesTextView)
        gravityTextView = findViewById(R.id.gravityTextView)
    }

    private fun initializeSensors() {
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        // Получаем датчик гравитации (может быть null)
        gravitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)

        if (gravitySensor == null) {
            // Если датчик гравитации недоступен, используем акселерометр
            gravitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            gravityTextView.text = "Используется акселерометр"
        } else {
            gravityTextView.text = "Используется датчик гравитации"
        }

        // Если оба датчика недоступны, показываем сообщение
        if (gravitySensor == null) {
            gravityTextView.text = "Датчики движения недоступны"
        }
    }

    override fun onResume() {
        super.onResume()
        gravitySensor?.let { sensor ->
            sensorManager.registerListener(
                this,
                sensor,
                SensorManager.SENSOR_DELAY_GAME
            )
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
        updateHandler.removeCallbacksAndMessages(null)
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_GRAVITY, Sensor.TYPE_ACCELEROMETER -> {
                gravityX = event.values[0]
                gravityY = event.values[1]
                gravityZ = event.values[2]

                updateGravityDisplay()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
        // Можно добавить обработку изменения точности
        when (accuracy) {
            SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> {
                // Высокая точность
            }
            SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> {
                // Средняя точность
            }
            SensorManager.SENSOR_STATUS_ACCURACY_LOW -> {
                // Низкая точность
            }
            SensorManager.SENSOR_STATUS_UNRELIABLE -> {
                // Данные недостоверны
            }
        }
    }

    private fun updateGravityDisplay() {
        val gravityText = String.format(
            "Gravity:\nX: %.2f\nY: %.2f\nZ: %.2f",
            gravityX, gravityY, gravityZ
        )
        gravityTextView.text = gravityText
    }

    private fun startGameLoop() {
        val updateRunnable = object : Runnable {
            override fun run() {
                updateBallPhysics()
                updateBallDisplay()
                updateHandler.postDelayed(this, updateInterval)
            }
        }
        updateHandler.post(updateRunnable)
    }

    private fun updateBallPhysics() {
        ballView.updatePhysics(gravityX, gravityY)
    }

    private fun updateBallDisplay() {
        ballView.invalidate()

        val coordinatesText = String.format(
            "Position:\nX: %.1f\nY: %.1f\nSpeed X: %.1f\nSpeed Y: %.1f",
            ballView.ballX, ballView.ballY, ballView.ballSpeedX, ballView.ballSpeedY
        )
        coordinatesTextView.text = coordinatesText
    }
}