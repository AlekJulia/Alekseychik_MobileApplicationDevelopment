package ru.alekseychick.alekseychik_ulia_lab25

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BookDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        const val DB_NAME = "books.db"
        const val DB_VERSION = 1

        const val TABLE_BOOKS = "books"
        const val COLUMN_ID = "id"
        const val COLUMN_TITLE = "title"
        const val COLUMN_AUTHOR = "author"
        const val COLUMN_DESCRIPTION = "description"
        const val COLUMN_STATUS = "status"
        const val COLUMN_ADDED_DATE = "added_date"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_BOOKS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_TITLE TEXT NOT NULL,
                $COLUMN_AUTHOR TEXT NOT NULL,
                $COLUMN_DESCRIPTION TEXT,
                $COLUMN_STATUS TEXT NOT NULL,
                $COLUMN_ADDED_DATE INTEGER NOT NULL
            )
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_BOOKS")
        onCreate(db)
    }

    // Добавление книги
    fun addBook(book: Book): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_TITLE, book.title)
            put(COLUMN_AUTHOR, book.author)
            put(COLUMN_DESCRIPTION, book.description)
            put(COLUMN_STATUS, book.status.name)
            put(COLUMN_ADDED_DATE, book.addedDate)
        }
        return db.insert(TABLE_BOOKS, null, values)
    }

    // Получение всех книг с сортировкой по статусу и дате
    fun getAllBooks(): List<Book> {
        val books = mutableListOf<Book>()
        val db = readableDatabase

        val cursor: Cursor = db.query(
            TABLE_BOOKS,
            null,
            null,
            null,
            null,
            null,
            "$COLUMN_STATUS DESC, $COLUMN_ADDED_DATE DESC" // Сначала новые, потом прочитанные
        )

        cursor.use {
            while (it.moveToNext()) {
                books.add(cursorToBook(it))
            }
        }
        return books
    }

    // Обновление книги
    fun updateBook(book: Book): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_TITLE, book.title)
            put(COLUMN_AUTHOR, book.author)
            put(COLUMN_DESCRIPTION, book.description)
            put(COLUMN_STATUS, book.status.name)
        }

        return db.update(
            TABLE_BOOKS,
            values,
            "$COLUMN_ID = ?",
            arrayOf(book.id.toString())
        )
    }

    // Удаление книги
    fun deleteBook(bookId: Long): Int {
        val db = writableDatabase
        return db.delete(
            TABLE_BOOKS,
            "$COLUMN_ID = ?",
            arrayOf(bookId.toString())
        )
    }

    // Получение книги по ID
    fun getBookById(id: Long): Book? {
        val db = readableDatabase
        val cursor: Cursor = db.query(
            TABLE_BOOKS,
            null,
            "$COLUMN_ID = ?",
            arrayOf(id.toString()),
            null,
            null,
            null
        )

        return cursor.use {
            if (it.moveToFirst()) {
                cursorToBook(it)
            } else {
                null
            }
        }
    }

    private fun cursorToBook(cursor: Cursor): Book {
        return Book(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)),
            title = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)),
            author = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AUTHOR)),
            description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)),
            status = BookStatus.valueOf(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS))),
            addedDate = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ADDED_DATE))
        )
    }
}