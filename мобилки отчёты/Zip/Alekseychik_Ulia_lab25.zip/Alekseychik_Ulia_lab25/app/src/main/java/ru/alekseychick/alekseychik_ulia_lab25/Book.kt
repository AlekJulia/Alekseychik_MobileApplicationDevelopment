package ru.alekseychick.alekseychik_ulia_lab25

import android.os.Parcel
import android.os.Parcelable

data class Book(
    val id: Long = 0,
    val title: String,
    val author: String,
    val description: String = "",
    val status: BookStatus,
    val addedDate: Long = System.currentTimeMillis()
) : Parcelable {

    constructor(parcel: Parcel) : this(
        id = parcel.readLong(),
        title = parcel.readString() ?: "",
        author = parcel.readString() ?: "",
        description = parcel.readString() ?: "",
        status = BookStatus.valueOf(parcel.readString() ?: "NEW"),
        addedDate = parcel.readLong()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeLong(id)
        parcel.writeString(title)
        parcel.writeString(author)
        parcel.writeString(description)
        parcel.writeString(status.name)
        parcel.writeLong(addedDate)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Book> {
        override fun createFromParcel(parcel: Parcel): Book {
            return Book(parcel)
        }

        override fun newArray(size: Int): Array<Book?> {
            return arrayOfNulls(size)
        }
    }
}

enum class BookStatus {
    NEW, READ
}