package ru.alekseychick.alekseychik_ulia_lab25


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import ru.alekseychick.alekseychik_ulia_lab25.R
import ru.alekseychick.alekseychik_ulia_lab25.Book
import ru.alekseychick.alekseychik_ulia_lab25.BookStatus

class BookAdapter(
    private val onItemClick: (Book) -> Unit,
    private val onItemLongClick: (Book) -> Boolean
) : ListAdapter<Book, BookAdapter.BookViewHolder>(BookDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_book, parent, false)
        return BookViewHolder(view)
    }

    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class BookViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.titleTextView)
        private val authorTextView: TextView = itemView.findViewById(R.id.authorTextView)
        private val descriptionTextView: TextView = itemView.findViewById(R.id.descriptionTextView)
        private val statusTextView: TextView = itemView.findViewById(R.id.statusTextView)

        fun bind(book: Book) {
            titleTextView.text = book.title
            authorTextView.text = book.author
            descriptionTextView.text = book.description

            when (book.status) {
                BookStatus.NEW -> {
                    statusTextView.text = "Новая"
                    statusTextView.setBackgroundColor(
                        ContextCompat.getColor(itemView.context, R.color.color_new)
                    )
                }
                BookStatus.READ -> {
                    statusTextView.text = "Прочитана"
                    statusTextView.setBackgroundColor(
                        ContextCompat.getColor(itemView.context, R.color.color_read)
                    )
                }
            }

            itemView.setOnClickListener {
                onItemClick(book)
            }

            itemView.setOnLongClickListener {
                onItemLongClick(book)
            }
        }
    }
}

class BookDiffCallback : DiffUtil.ItemCallback<Book>() {
    override fun areItemsTheSame(oldItem: Book, newItem: Book): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Book, newItem: Book): Boolean {
        return oldItem == newItem
    }
}