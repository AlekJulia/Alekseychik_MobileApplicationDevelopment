package ru.alekseychick.alekseychik_ulia_lab25

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import ru.alekseychick.alekseychik_ulia_lab25.Book
import ru.alekseychick.alekseychik_ulia_lab25.BookDatabase
import ru.alekseychick.alekseychik_ulia_lab25.BookAdapter
import ru.alekseychick.alekseychik_ulia_lab25.BookDialogFragment

class MainActivity : AppCompatActivity(), BookDialogFragment.BookDialogListener {

    private lateinit var database: BookDatabase
    private lateinit var adapter: BookAdapter
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        database = BookDatabase(this)

        setupRecyclerView()
        setupFab()
        loadBooks()
    }

    private fun setupRecyclerView() {
        recyclerView = findViewById(R.id.recyclerView)
        adapter = BookAdapter(
            onItemClick = { book ->
                showEditBookDialog(book)
            },
            onItemLongClick = { book ->
                showDeleteConfirmation(book)
                true
            }
        )

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun setupFab() {
        val fab = findViewById<FloatingActionButton>(R.id.fab)
        fab.setOnClickListener {
            showAddBookDialog()
        }
    }

    private fun loadBooks() {
        val books = database.getAllBooks()
        adapter.submitList(books)
    }

    private fun showAddBookDialog() {
        val dialog = BookDialogFragment.newInstance()
        dialog.setListener(this)
        dialog.show(supportFragmentManager, "BookDialog")
    }

    private fun showEditBookDialog(book: Book) {
        val dialog = BookDialogFragment.newInstance(book)
        dialog.setListener(this)
        dialog.show(supportFragmentManager, "BookDialog")
    }

    private fun showDeleteConfirmation(book: Book) {
        android.app.AlertDialog.Builder(this)
            .setTitle("Удаление книги")
            .setMessage("Вы уверены, что хотите удалить книгу \"${book.title}\"?")
            .setPositiveButton("Удалить") { _, _ ->
                deleteBook(book)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onBookSaved(book: Book) {
        if (book.id == 0L) {
            // Новая книга
            val newId = database.addBook(book)
            if (newId != -1L) {
                Toast.makeText(this, "Книга добавлена", Toast.LENGTH_SHORT).show()
                loadBooks()
            } else {
                Toast.makeText(this, "Ошибка при добавлении книги", Toast.LENGTH_SHORT).show()
            }
        } else {
            // Обновление существующей книги
            val updatedRows = database.updateBook(book)
            if (updatedRows > 0) {
                Toast.makeText(this, "Книга обновлена", Toast.LENGTH_SHORT).show()
                loadBooks()
            } else {
                Toast.makeText(this, "Ошибка при обновлении книги", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun deleteBook(book: Book) {
        val deletedRows = database.deleteBook(book.id)
        if (deletedRows > 0) {
            Toast.makeText(this, "Книга удалена", Toast.LENGTH_SHORT).show()
            loadBooks()
        } else {
            Toast.makeText(this, "Ошибка при удалении книги", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        database.close()
        super.onDestroy()
    }
}