package ru.alekseychick.alekseychik_ulia_lab25

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.fragment.app.DialogFragment
import ru.alekseychick.alekseychik_ulia_lab25.R
import ru.alekseychick.alekseychik_ulia_lab25.Book
import ru.alekseychick.alekseychik_ulia_lab25.BookStatus

class BookDialogFragment : DialogFragment() {

    interface BookDialogListener {
        fun onBookSaved(book: Book)
    }

    private var listener: BookDialogListener? = null
    private var existingBook: Book? = null

    companion object {
        private const val ARG_BOOK = "book"

        fun newInstance(book: Book? = null): BookDialogFragment {
            val args = Bundle().apply {
                if (book != null) {
                    putParcelable(ARG_BOOK, book)
                }
            }
            return BookDialogFragment().apply {
                arguments = args
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        existingBook = arguments?.getParcelable(ARG_BOOK)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val inflater = requireActivity().layoutInflater
        val view = inflater.inflate(R.layout.dialog_book, null)

        val titleEditText = view.findViewById<EditText>(R.id.titleEditText)
        val authorEditText = view.findViewById<EditText>(R.id.authorEditText)
        val descriptionEditText = view.findViewById<EditText>(R.id.descriptionEditText)
        val statusSpinner = view.findViewById<Spinner>(R.id.statusSpinner)

        // Настройка спиннера статусов
        val statuses = BookStatus.values().map { it.name }
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, statuses)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        statusSpinner.adapter = adapter

        // Заполнение полей, если редактируем существующую книгу
        existingBook?.let { book ->
            titleEditText.setText(book.title)
            authorEditText.setText(book.author)
            descriptionEditText.setText(book.description)
            statusSpinner.setSelection(statuses.indexOf(book.status.name))
        }

        return AlertDialog.Builder(requireContext())
            .setTitle(if (existingBook != null) "Редактировать книгу" else "Добавить книгу")
            .setView(view)
            .setPositiveButton("Сохранить") { _, _ ->
                val title = titleEditText.text.toString().trim()
                val author = authorEditText.text.toString().trim()
                val description = descriptionEditText.text.toString().trim()
                val status = BookStatus.valueOf(statusSpinner.selectedItem.toString())

                if (title.isNotEmpty() && author.isNotEmpty()) {
                    val book = existingBook?.copy(
                        title = title,
                        author = author,
                        description = description,
                        status = status
                    ) ?: Book(
                        title = title,
                        author = author,
                        description = description,
                        status = status
                    )

                    listener?.onBookSaved(book)
                }
            }
            .setNegativeButton("Отмена", null)
            .create()
    }

    fun setListener(listener: BookDialogListener) {
        this.listener = listener
    }
}