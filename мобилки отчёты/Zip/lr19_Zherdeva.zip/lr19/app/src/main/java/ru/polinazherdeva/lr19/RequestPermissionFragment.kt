package ru.polinazherdeva.lr19


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import ru.polinazherdeva.lr19.databinding.FragmentRequestPermissionBinding

class RequestPermissionFragment : Fragment() {

    // ViewBinding для доступа к элементам интерфейса из XML
    private lateinit var binding: FragmentRequestPermissionBinding
    // Получаем ViewModel, общую с активностью (MainActivity),
    // чтобы можно было вызывать методы проверки и запроса разрешения
    private val viewModel: PermissionViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Создаем объект binding, чтобы связать XML с кодом
        binding = FragmentRequestPermissionBinding.inflate(inflater, container, false)
        // Обработчик нажатия кнопки "Получить контакты"
        binding.btnGetContacts.setOnClickListener {
            viewModel.checkPermission() // Проверка на наличие разрешения
            // Получаем ссылку на MainActivity, чтобы вызвать её launcher
            val activity = requireActivity() as MainActivity
            // Запускаем запрос разрешения на чтение контактов
            viewModel.requestPermission(activity.getLauncher())
        }

        return binding.root
    }
}
