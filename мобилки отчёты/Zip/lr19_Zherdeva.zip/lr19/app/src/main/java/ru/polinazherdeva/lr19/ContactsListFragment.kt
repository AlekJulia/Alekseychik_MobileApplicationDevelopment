package ru.polinazherdeva.lr19

import android.annotation.SuppressLint
import android.os.Bundle
import android.provider.ContactsContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import ru.polinazherdeva.lr19.databinding.FragmentContactsListBinding

class ContactsListFragment : Fragment() {

    private lateinit var binding: FragmentContactsListBinding // Переменная для доступа к элементам интерфейса через View Binding

    override fun onCreateView(
        inflater: LayoutInflater, // объект для раздувания (создания) разметки из XML
        container: ViewGroup?, // контейнер, в который будет вставлен фрагмент
        savedInstanceState: Bundle?
    ): View {
        // Создаём binding, который связывает XML с Kotlin-кодом
        binding = FragmentContactsListBinding.inflate(inflater, container, false)
        showContacts()
        return binding.root // Возвращаем корневое представление фрагмента (для отображения на экране)
    }

    @SuppressLint("Range") // Подавление предупреждения
    private fun showContacts() {
        val contacts = mutableListOf<String>() // Список для имен контактов
        val resolver = requireContext().contentResolver // Получаем contentResolver - через него можно обращаться к контактам

        // Делаем запрос ко всем контактам в телефоне
        resolver.query(
            ContactsContract.Contacts.CONTENT_URI, // URI всех контактов
            null, // какие столбцы брать (null = все)
            null, null, null // условия выборки и сортировки
        )?.use { cursor ->
            // Получаем индекс столбца, где хранится имя контакта
            val nameColumn = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
            // Проходим по всем строкам результата
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameColumn) // Извлекаем имя контакта из текущей строки
                contacts.add(name) // Добавляем имя в список
            }
        }

        // Определяем, какой текст показать пользователю
        val text = if (contacts.isEmpty()) {
            getString(R.string.contacts_not_found)  // Если контактов нет
        } else {
            // Если контакты есть — добавляем заголовок и список имён
            "${getString(R.string.contacts_success)}\n\n${contacts.joinToString("\n")}"
        }

        // Устанавливаем готовый текст в TextView на экране
        binding.tvContacts.text = text
    }
}
