package ru.polinazherdeva.lr19

import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit
import ru.polinazherdeva.lr19.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding // View Binding для доступа к элементам activity_main.xml
    private val viewModel: PermissionViewModel by viewModels() // ViewModel, которая управляет разрешениями

    // Регистрация "лаунчера" — объекта для запроса разрешения у пользователя
    private val permissionLauncher =
        // // Вызывается, когда пользователь ответит на запрос разрешения
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                openContactsFragment()  // Если пользователь разрешил — открываем фрагмент с контактами
            } else {
                openDeniedPermissionFragment() // Если отказал — открываем фрагмент с уведомлением об отказе
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Загружаем первый фрагмент — запрос разрешения
        supportFragmentManager.commit {
            replace(R.id.fragmentContainer, RequestPermissionFragment())
        }

        // Подписываемся на изменение значения LiveData (из ViewModel)
        // Когда разрешение будет выдано, автоматически откроется ContactsListFragment
        viewModel.permissionGranted.observe(this) { granted ->
            if (granted) openContactsFragment()
        }
    }

    // Функция для открытия фрагмента со списком контактов
    fun openContactsFragment() {
        supportFragmentManager.commit {
            replace(R.id.fragmentContainer, ContactsListFragment())
        }
    }

    // Функция для открытия фрагмента, если пользователь отказал в разрешении
    fun openDeniedPermissionFragment() {
        supportFragmentManager.commit {
            replace(R.id.fragmentContainer, DeniedPermissionFragment())
        }
    }

    // Функция для передачи лаунчера в другие фрагменты (например, RequestPermissionFragment)
    fun getLauncher() = permissionLauncher
}
