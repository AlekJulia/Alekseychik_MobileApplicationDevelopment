package ru.polinazherdeva.lr19

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import ru.polinazherdeva.lr19.databinding.FragmentDeniedPermissionBinding

class DeniedPermissionFragment : Fragment() {

    // View Binding для доступа к элементам интерфейса
    private lateinit var binding: FragmentDeniedPermissionBinding

    // Получаем ViewModel, общую для Activity и всех фрагментов
    private val viewModel: PermissionViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDeniedPermissionBinding.inflate(inflater, container, false)

        // Обработчик нажатия на кнопку «Открыть настройки»
        binding.btnOpenSettings.setOnClickListener {
            viewModel.openSettings() // Открытие системных настроек приложения
        }

        // Обработчик нажатия на кнопку «Нет, спасибо»
        binding.btnNoThanks.setOnClickListener {
            requireActivity().finish() // Закрываем Activity и выходим из приложения
        }

        return binding.root  // Возвращаем корневое представление фрагмента
    }
}
