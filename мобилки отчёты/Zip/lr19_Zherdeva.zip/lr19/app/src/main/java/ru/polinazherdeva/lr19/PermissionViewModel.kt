package ru.polinazherdeva.lr19

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.result.ActivityResultLauncher
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData

class PermissionViewModel(app: Application) : AndroidViewModel(app) {

    // LiveData, хранящая состояние: выдано ли разрешение (true/false)
    // Активность и фрагменты могут наблюдать за этим значением
    val permissionGranted = MutableLiveData<Boolean>()
    // Получаем контекст приложения, чтобы можно было вызывать системные функции
    private val context = app.applicationContext

    // Проверяем, есть ли у приложения разрешение на чтение контактов
    fun checkPermission() {
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
        permissionGranted.value = granted // Обновляем LiveData
    }

    // Метод для запроса разрешения через специальный launcher
    // launcher передается из Activity
    fun requestPermission(launcher: ActivityResultLauncher<String>) {
        launcher.launch(Manifest.permission.READ_CONTACTS)  // Запускаем системное окно с просьбой разрешить доступ к контактам
    }

    // Метод открывает настройки приложения, если пользователь запретил разрешение
    fun openSettings() {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            // Открываем страницу настроек конкретного приложения
            Uri.parse("package:${context.packageName}") // Адрес с именем пакета текущего приложения
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK // Добавляем флаг, чтобы запуск происходил вне текущего стека (нужно для контекста приложения)
        }
        // Запускаем активность настроек
        context.startActivity(intent)
    }
}
