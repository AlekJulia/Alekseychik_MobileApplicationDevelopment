package ru.polinazherdeva.lr21

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var timerText: TextView
    private lateinit var startButton: Button
    private lateinit var minutesInput: EditText
    private lateinit var secondsInput: EditText
    private var timerRunning = false // флаг — запущен ли таймер

    // Приёмник сообщений от службы TimerService (каждую секунду получает оставшееся время)
    private val timerBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == TimerService.ACTION_TIMER_TICK) {
                val millisLeft = intent.getLongExtra(TimerService.EXTRA_TIME_LEFT, 0L)
                if (millisLeft > 0) {
                    timerText.text = formatTime(millisLeft) // обновляем текст с оставшимся временем
                } else {
                    timerText.text = getString(R.string.timer_ready)  // выводим "таймер готов"
                    timerRunning = false
                    startButton.text = getString(R.string.start_button)
                    setInputsEnabled(true) // разблокируем поля после окончания таймера
                }
            }
        }
    }

    // Запрос разрешения на уведомления
    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) toggleTimer() // если разрешение дано — запускаем таймер
            else Toast.makeText(this, "Нужны разрешения для уведомлений", Toast.LENGTH_SHORT).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // подключаем разметку

        // Находим элементы интерфейса
        timerText = findViewById(R.id.timerText)
        startButton = findViewById(R.id.startButton)
        minutesInput = findViewById(R.id.minutesInput)
        secondsInput = findViewById(R.id.secondsInput)

        // Обработка нажатия на кнопку
        startButton.setOnClickListener { checkNotificationPermissionAndToggle() }
    }

    // Проверка разрешения на уведомления и запуск/остановка таймера
    private fun checkNotificationPermissionAndToggle() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Если разрешения нет — запрашиваем его
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                toggleTimer() // иначе — запускаем таймер
            }
        } else {
            toggleTimer() // для старых версий Android разрешения не нужны
        }
    }

    // Запуск или остановка таймера
    private fun toggleTimer() {
        if (!timerRunning) {
            // Запуск таймера
            val minutes = minutesInput.text.toString().toLongOrNull() ?: 0
            val seconds = secondsInput.text.toString().toLongOrNull() ?: 0
            val totalMillis = (minutes * 60 + seconds) * 1000

            // Проверяем, что введено корректное время
            if (totalMillis <= 0) {
                Toast.makeText(this, "Введите время больше 0", Toast.LENGTH_SHORT).show()
                return
            }
            // Создаём Intent для запуска сервиса
            val intent = Intent(this, TimerService::class.java).apply {
                action = TimerService.ACTION_START_TIMER
                putExtra(TimerService.EXTRA_TIME_LEFT, totalMillis)
            }
            ContextCompat.startForegroundService(this, intent)  // запускаем сервис переднего плана

            timerRunning = true
            startButton.text = getString(R.string.stop_button) // меняем текст кнопки на стоп
            setInputsEnabled(false) //  блокируем поля во время работы таймера
        } else {
            // Остановка таймера
            val intent = Intent(this, TimerService::class.java).apply {
                action = TimerService.ACTION_STOP_TIMER
            }
            startService(intent) // отправляем сигнал сервису

            timerRunning = false
            startButton.text = getString(R.string.start_button)
            timerText.text = getString(R.string.timer_ready)
            setInputsEnabled(true) // разблокируем поля после остановки
        }
    }

    // Форматирование времени в мм:сс
    private fun formatTime(millis: Long): String {
        val totalSeconds = millis / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    // Регистрация приёмника
    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            timerBroadcastReceiver, // указываем приёмник
            IntentFilter(TimerService.ACTION_TIMER_TICK), // фильтр действий
            ContextCompat.RECEIVER_EXPORTED // приёмник доступен извне
        )
    }

    // Отмена регистрации приёмника
    override fun onStop() {
        super.onStop()
        unregisterReceiver(timerBroadcastReceiver)
    }

    // Метод для включения/отключения полей ввода
    private fun setInputsEnabled(enabled: Boolean) {
        minutesInput.isEnabled = enabled
        secondsInput.isEnabled = enabled
    }
}