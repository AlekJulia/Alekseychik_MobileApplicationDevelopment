package ru.polinazherdeva.lr21

import android.app.NotificationChannel
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

// Сервис — компонент, выполняющий задачу в фоне
class TimerService : Service() {

    // companion object — хранит константы, общие для всего приложения
    companion object {
        const val ACTION_START_TIMER = "ACTION_START_TIMER" // действие для запуска таймера
        const val ACTION_STOP_TIMER = "ACTION_STOP_TIMER"  // действие для остановки таймера
        const val ACTION_TIMER_TICK = "ACTION_TIMER_TICK" // действие — событие «тик» (каждую секунду)
        const val EXTRA_TIME_LEFT = "EXTRA_TIME_LEFT" // ключ для передачи оставшегося времени
        const val CHANNEL_ID = "timer_channel" // ID канала уведомлений
        const val NOTIFICATION_ID = 1 // ID уведомления
    }

    private var timer: CountDownTimer? = null // объект обратного отсчёта
    private var remainingTime: Long = 60000L // оставшееся время (по умолчанию 60 сек)
    private lateinit var notificationBuilder: NotificationCompat.Builder // конструктор уведомлений

    // Основной метод запуска сервиса. Срабатывает при вызове startForegroundService() или startService()
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) { // проверяем, какое действие пришло в Intent
            ACTION_START_TIMER -> { // если действие — "запустить таймер"
                remainingTime = intent.getLongExtra(EXTRA_TIME_LEFT, 60000L) // получаем время из Intent
                startForegroundServiceSafe() // запускаем сервис в переднем плане с уведомлением
                startCountDown()  // запускаем сам отсчёт
            }
            ACTION_STOP_TIMER -> {  // если действие — "остановить таймер"
                stopTimer() // останавливаем таймер
            }
        }
        return START_STICKY // START_STICKY — если система убьёт сервис, она перезапустит его без нового Intent
    }

    // Метод, который создаёт уведомление и переводит сервис в режим переднего плана
    private fun startForegroundServiceSafe() {
        val manager = NotificationManagerCompat.from(this) // менеджер уведомлений
        createNotificationChannel(manager) // создаём канал уведомлений

        // Настраиваем уведомление
        notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Таймер") // заголовок уведомления
            .setContentText(formatTime(remainingTime)) // текст — оставшееся время
            .setSmallIcon(R.drawable.ic_art) // иконка
            .setOnlyAlertOnce(true) // не издавать звук при каждом обновлении
        // Запускаем сервис в режиме переднего плана
        try {
            startForeground(NOTIFICATION_ID, notificationBuilder.build())
        } catch (e: SecurityException) {
            e.printStackTrace() // обработка ошибки при отсутствии разрешений
        }
    }

    // Создаём канал уведомлений
    private fun createNotificationChannel(manager: NotificationManagerCompat) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, // ID канала
                "Таймер",  // имя канала
                android.app.NotificationManager.IMPORTANCE_LOW // низкий приоритет
            )
            manager.createNotificationChannel(channel) // регистрируем канал в системе
        }
    }

    // Метод, запускающий обратный отсчёт
    private fun startCountDown() {
        timer?.cancel() // если предыдущий таймер существовал — отменяем его
        timer = object : CountDownTimer(remainingTime, 1000) {  // создаём таймер с шагом 1 сек
            override fun onTick(millisUntilFinished: Long) {
                remainingTime = millisUntilFinished // сохраняем оставшееся время

                // Обновляем текст в уведомлении
                notificationBuilder.setContentText("Осталось: ${formatTime(remainingTime)}")
                try {
                    NotificationManagerCompat.from(this@TimerService)
                        .notify(NOTIFICATION_ID, notificationBuilder.build()) // обновляем уведомление
                } catch (e: SecurityException) { e.printStackTrace() }

                // Отправляем широковещательное сообщение (Broadcast) в MainActivity
                sendBroadcast(Intent(ACTION_TIMER_TICK).apply {
                    putExtra(EXTRA_TIME_LEFT, remainingTime)  // передаём оставшееся время
                })
            }
            // Действия после завершения отсчёта
            override fun onFinish() {
                remainingTime = 0L
                // Отправляем сообщение о том, что время вышло
                sendBroadcast(Intent(ACTION_TIMER_TICK).apply {
                    putExtra(EXTRA_TIME_LEFT, remainingTime)
                })
                stopTimer() // останавливаем сервис
            }
        }.start() // запускаем таймер
    }

    // Остановка таймера
    private fun stopTimer() {
        timer?.cancel()  // останавливаем обратный отсчёт
        stopForegroundService() // снимаем сервис с переднего плана
    }

    // Остановка сервиса переднего плана и завершение его работы
    private fun stopForegroundService() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
        stopSelf() // полностью останавливаем сервис
    }

    // Форматируем миллисекунды в строку "мм:сс"
    private fun formatTime(millis: Long): String {
        val totalSeconds = millis / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    override fun onBind(intent: Intent?): IBinder? = null // Сервис не поддерживает привязку, поэтому возвращаем null
}
