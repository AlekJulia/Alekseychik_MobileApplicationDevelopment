package ru.alekseychick.alekseychik_ulia_lab22

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.math.*

class MainActivity : AppCompatActivity(), LocationListener {

    // объявление UI элементов
    private lateinit var locationManager: LocationManager
    private lateinit var statusTextView: TextView
    private lateinit var distanceTextView: TextView
    private lateinit var targetPointTextView: TextView
    private lateinit var currentLocationTextView: TextView
    private lateinit var generatePointButton: Button
    private lateinit var settingsButton: Button

    // переменные для хранения локаций и состояния игры
    private var currentLocation: Location? = null
    private var targetLocation: Location? = null
    private var isGameActive = false
    private var isWaitingForLocation = false

    // константы для расчетов расстояний
    private companion object {
        const val EARTH_RADIUS = 6371000.0
        const val TARGET_RADIUS_METERS = 2500.0
        const val SUCCESS_DISTANCE_METERS = 100.0
        const val DEGREES_PER_5_KM = 0.04
    }

    // запрос разрешения на локицию
    private val locationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        when {
            permissions.getOrDefault(Manifest.permission.ACCESS_FINE_LOCATION, false) ||
                    permissions.getOrDefault(Manifest.permission.ACCESS_COARSE_LOCATION, false) -> {
                // разрешения предоставлены - запускается отслеживание локации
                startLocationUpdates()
                Toast.makeText(this, "Доступ к местоположению предоставлен", Toast.LENGTH_SHORT).show()
            }
            else -> {
                // разрешения не предоставлены - показывается диалог
                showPermissionRequiredDialog()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // инициализация всех компонентов приложения
        initializeViews()
        setupClickListeners()
        initializeLocationManager()
        checkLocationPermissions()
    }

    // инициализация всех View элементов из layout
    private fun initializeViews() {
        statusTextView = findViewById(R.id.statusTextView)
        distanceTextView = findViewById(R.id.distanceTextView)
        targetPointTextView = findViewById(R.id.targetPointTextView)
        currentLocationTextView = findViewById(R.id.currentLocationTextView)
        generatePointButton = findViewById(R.id.generatePointButton)
        settingsButton = findViewById(R.id.settingsButton)

        // показывается сообщение о ожидании местоположения
        currentLocationTextView.text = "Определение местоположения"
    }

    // настройка обработчиков кликов для кнопок
    private fun setupClickListeners() {
        generatePointButton.setOnClickListener {
            // проверка разрешений перед генерацией точки
            if (!hasLocationPermissions()) {
                showPermissionExplanationDialog()
                return@setOnClickListener
            }

            if (currentLocation == null) {
                // ожидание определения местоположения, если оно не определено
                isWaitingForLocation = true
                statusTextView.text = "Ожидание определения местоположения"
                statusTextView.setTextColor(ContextCompat.getColor(this, R.color.color_waiting))
                Toast.makeText(this, "Ожидайте определения местоположения", Toast.LENGTH_SHORT).show()

                // попытка получить последнее известное местоположение
                tryGetLastKnownLocation()
            } else {
                // есть локация - генерация новой точки
                generateNewTargetPoint()
            }
        }

        settingsButton.setOnClickListener {
            // показывается диалог настроек
            showSettingsDialog()
        }
    }

    // получение сервиса менеджера локации
    private fun initializeLocationManager() {
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
    }

    // проверка наличия разрешений на локацию
    private fun hasLocationPermissions(): Boolean {
        val fineLocationGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseLocationGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        return fineLocationGranted || coarseLocationGranted
    }

    // проверка и запрос разрешений
    private fun checkLocationPermissions() {
        if (hasLocationPermissions()) {
            startLocationUpdates()
        }
    }

    // запрос разрешений у пользователя
    private fun requestLocationPermissions() {
        locationPermissionRequest.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    // запуск получения обновлений локации
    private fun startLocationUpdates() {
        if (!hasLocationPermissions()) return

        try {
            // проверка доступности провайдеров GPS и сети
            val isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
            val isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

            if (!isGpsEnabled && !isNetworkEnabled) {
                showLocationServicesDialog()
                return
            }

            // запрос частых обновлений от GPS провайдера
            if (isGpsEnabled) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    500L, // Интервал 500 мс
                    0f,   // Без минимального расстояния
                    this
                )
            }

            // запрос обновлений от сетевого провайдера
            if (isNetworkEnabled) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    1000L, // интервал 1 секунда
                    0f,    // без минимального расстояния
                    this
                )
            }

            // попытка получения последнего местоположения
            tryGetLastKnownLocation()

        } catch (e: SecurityException) {
            Toast.makeText(this, "Ошибка безопасности при доступе к местоположению", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка при запуске службы местоположения", Toast.LENGTH_SHORT).show()
        }
    }

    // попытка получить последнюю известную локацию
    private fun tryGetLastKnownLocation() {
        try {
            var lastLocation: Location? = null

            // получение точной GPS локации
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                lastLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            }

            // иначе получение сетевуой локации
            if (lastLocation == null && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                lastLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            }

            // обновление интерфейса, если локация найдена
            lastLocation?.let { location ->
                onLocationChanged(location)
            }

        } catch (e: SecurityException) {

        }
    }

    // обработчик изменения локации
    override fun onLocationChanged(location: Location) {
        // проверка видимости местоположения
        if (location.latitude == 0.0 && location.longitude == 0.0) {
            return
        }

        currentLocation = location
        updateCurrentLocationDisplay()

        // генерации точки, если было ожидание
        if (isWaitingForLocation) {
            isWaitingForLocation = false
            generateNewTargetPoint()
        }

        // обновление расстояние до цели при активной игре
        if (isGameActive && targetLocation != null) {
            calculateAndUpdateDistance()
        }
    }

    // обновление отображения текущей локации
    private fun updateCurrentLocationDisplay() {
        currentLocation?.let { location ->
            val locationText = String.format(
                "Ш: %.6f\nД: %.6f\nТочность: %.1fм",
                location.latitude,
                location.longitude,
                location.accuracy
            )
            currentLocationTextView.text = locationText

            // обнавление статуса, если игра не активна
            if (!isGameActive) {
                statusTextView.text = getString(R.string.status_waiting)
                statusTextView.setTextColor(ContextCompat.getColor(this, R.color.color_waiting))
            }
        }
    }

    // генерация новой точки в радиусе 2.5 км
    private fun generateNewTargetPoint() {
        currentLocation?.let { currentLoc ->
            // генерация случайного расстояния и угла
            val randomDistance = Math.random() * TARGET_RADIUS_METERS
            val randomAngle = Math.random() * 2 * Math.PI

            // преобразование расстояния в градусы
            val degreesOffset = (randomDistance / 5000) * DEGREES_PER_5_KM

            // расчет координат целевой точки
            val targetLat = currentLoc.latitude + degreesOffset * cos(randomAngle)
            val targetLon = currentLoc.longitude + degreesOffset * sin(randomAngle)

            targetLocation = Location("target").apply {
                latitude = targetLat
                longitude = targetLon
            }

            updateTargetPointDisplay()
            startGame()

            Toast.makeText(this, "Точка загадана! Начинайте поиск!", Toast.LENGTH_SHORT).show()

        } ?: run {
            Toast.makeText(this, "Не удалось определить текущее местоположение", Toast.LENGTH_SHORT).show()
        }
    }

    // обновление отображения целевой точки
    private fun updateTargetPointDisplay() {
        targetLocation?.let { location ->
            val targetText = String.format(
                "Ш: %.6f\nД: %.6f",
                location.latitude,
                location.longitude
            )
            targetPointTextView.text = targetText
        }
    }

    // запуск игры - активация отслеживания расстояния
    private fun startGame() {
        isGameActive = true
        statusTextView.text = getString(R.string.status_point_generated)
        statusTextView.setTextColor(ContextCompat.getColor(this, R.color.color_searching))

        // расчёт начального расстояния
        currentLocation?.let {
            calculateAndUpdateDistance()
        }
    }

    // расчет и обновление расстояния до цели
    private fun calculateAndUpdateDistance() {
        if (currentLocation == null || targetLocation == null) return

        val distance = calculateDistance(
            currentLocation!!.latitude,
            currentLocation!!.longitude,
            targetLocation!!.latitude,
            targetLocation!!.longitude
        )

        updateDistanceDisplay(distance)
        checkForSuccess(distance)
    }

    // расчет расстояния между двумя точками по формуле гаверсинусов
    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val lat1Rad = Math.toRadians(lat1)
        val lat2Rad = Math.toRadians(lat2)
        val deltaLonRad = Math.toRadians(lon2 - lon1)

        val centralAngle = acos(
            sin(lat1Rad) * sin(lat2Rad) +
                    cos(lat1Rad) * cos(lat2Rad) * cos(deltaLonRad)
        )

        return EARTH_RADIUS * centralAngle
    }

    // обновление отображения расстояния (в метрах или км)
    private fun updateDistanceDisplay(distance: Double) {
        val distanceText = when {
            distance >= 1000 -> String.format("%.2f км", distance / 1000)
            else -> String.format("%.0f метров", distance)
        }
        distanceTextView.text = distanceText
    }

    // проверка достижения цели (в радиусе 100 метров)
    private fun checkForSuccess(distance: Double) {
        if (distance <= SUCCESS_DISTANCE_METERS) {
            isGameActive = false
            statusTextView.text = getString(R.string.status_point_found)
            statusTextView.setTextColor(ContextCompat.getColor(this, R.color.color_found))
            Toast.makeText(this, "Поздравляем! Вы нашли точку!", Toast.LENGTH_LONG).show()
        }
    }

    // диалог объяснения необходимости разрешений
    private fun showPermissionExplanationDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.permission_required))
            .setMessage(getString(R.string.location_permission_description))
            .setPositiveButton(getString(R.string.grant_permission)) { _, _ ->
                requestLocationPermissions()
            }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }

    // диалог когда разрешения не даны
    private fun showPermissionRequiredDialog() {
        AlertDialog.Builder(this)
            .setTitle("Разрешения не предоставлены")
            .setMessage("Для работы игры необходимо предоставить доступ к местоположению.")
            .setPositiveButton("Предоставить") { _, _ ->
                requestLocationPermissions()
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    // диалог когда службы локации выключены
    private fun showLocationServicesDialog() {
        AlertDialog.Builder(this)
            .setTitle("Службы местоположения отключены")
            .setMessage("Для работы приложения необходимо включить службы местоположения (GPS или сеть).")
            .setPositiveButton("Включить") { _, _ ->
                openLocationSettings()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // диалог настроек приложения
    private fun showSettingsDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.settings_title))
            .setMessage(getString(R.string.location_permission_description))
            .setPositiveButton(getString(R.string.open_settings)) { _, _ ->
                openAppSettings()
            }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }

    // открытие системных настроек локации
    private fun openLocationSettings() {
        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        startActivity(intent)
    }

    // открытие настроек приложения
    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }

    // возобновление отслеживания локации при возврате в приложение
    override fun onResume() {
        super.onResume()
        if (hasLocationPermissions()) {
            startLocationUpdates()
        }
    }

    // остановка отслеживания локации при уходе из приложения
    override fun onPause() {
        super.onPause()
        stopLocationUpdates()
    }

    // остановка получения обновлений локации
    private fun stopLocationUpdates() {
        try {
            locationManager.removeUpdates(this)
        } catch (e: SecurityException) {

        }
    }

    // обработчик включения провайдера локации
    override fun onProviderEnabled(provider: String) {
        Toast.makeText(this, "Провайдер $provider включен", Toast.LENGTH_SHORT).show()
    }

    // обработчик отключения провайдера локации
    override fun onProviderDisabled(provider: String) {
        Toast.makeText(this, "Провайдер $provider отключен", Toast.LENGTH_SHORT).show()
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
}