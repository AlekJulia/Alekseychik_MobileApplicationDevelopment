package ru.polinazherdeva.lr26

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import android.widget.*
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    // --- UI элементы ---
    private lateinit var previewView: PreviewView         // Элемент для отображения камеры
    private lateinit var colorPreview: View              // Прямоугольник, показывающий текущий цвет
    private lateinit var colorHexText: TextView          // TextView для HTML-кода цвета
    private lateinit var captureButton: ImageButton      // Кнопка для съемки фото

    private var imageCapture: ImageCapture? = null       // Объект CameraX для фотосъемки

    // --- Разрешение на камеру ---
    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            // Если пользователь дал разрешение
            if (isGranted) {
                startCamera() // Запускаем камеру
            } else {
                Toast.makeText(this, "Разрешение на камеру отклонено", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Связываем с разметкой

        // Находим View по ID
        previewView = findViewById(R.id.previewView)
        colorPreview = findViewById(R.id.colorPreview)
        colorHexText = findViewById(R.id.colorHexText)
        captureButton = findViewById(R.id.capture)

        // Проверка разрешения на камеру
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera() // Разрешение уже есть — запускаем камеру
        } else {
            // Разрешения нет — запрашиваем
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }

        // Обработка нажатия кнопки съемки
        captureButton.setOnClickListener {
            takePhoto()
        }
    }

    // --- Метод инициализации камеры ---
    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        // Ждем получения CameraProvider
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            // Создаем предварительный просмотр камеры
            val preview = Preview.Builder()
                .build()
                .also {
                    it.surfaceProvider = previewView.surfaceProvider // Подключаем PreviewView
                }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA // Используем заднюю камеру

            // Настройка фотосъемки
            imageCapture = ImageCapture.Builder()
                .setTargetRotation(previewView.display.rotation) // Учитываем поворот экрана
                .build()

            // Настройка анализа изображения (для считывания цвета)
            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST) // Берем только последний кадр
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888) // Формат YUV
                .build()

            // Подключаем анализатор изображений
            imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this)) { imageProxy ->
                processImage(imageProxy) // Обработка кадра
            }

            try {
                cameraProvider.unbindAll() // Отвязываем все предыдущие use cases
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture, imageAnalysis
                ) // Привязываем камеру к жизненному циклу Activity
            } catch (exc: Exception) {
                Toast.makeText(this, "Ошибка инициализации камеры", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // --- Метод обработки кадра для получения цвета центра ---
    private fun processImage(imageProxy: ImageProxy) {
        try {
            // Получаем буферы Y, U и V (формат YUV_420_888)
            val yPlane = imageProxy.planes[0].buffer
            val uPlane = imageProxy.planes[1].buffer
            val vPlane = imageProxy.planes[2].buffer

            // Страйды и пиксельный шаг для корректного доступа к данным
            val yRowStride = imageProxy.planes[0].rowStride
            val uvRowStride = imageProxy.planes[1].rowStride
            val uvPixelStride = imageProxy.planes[1].pixelStride

            val width = imageProxy.width
            val height = imageProxy.height

            // Центр кадра
            val centerX = width / 2
            val centerY = height / 2

            // Индексы центрального пикселя в буферах
            val yIndex = centerY * yRowStride + centerX
            val uvIndex = (centerY / 2) * uvRowStride + (centerX / 2) * uvPixelStride

            // Считываем YUV значения
            val y = (yPlane.get(yIndex).toInt() and 0xFF)
            val u = (uPlane.get(uvIndex).toInt() and 0xFF) - 128
            val v = (vPlane.get(uvIndex).toInt() and 0xFF) - 128

            // Конвертация YUV -> RGB
            var r = (y + 1.370705f * v).toInt()
            var g = (y - 0.337633f * u - 0.698001f * v).toInt()
            var b = (y + 1.732446f * u).toInt()

            // Ограничиваем значения RGB в диапазоне 0–255
            r = r.coerceIn(0, 255)
            g = g.coerceIn(0, 255)
            b = b.coerceIn(0, 255)

            // Формируем цвет и HTML-код
            val colorInt = Color.rgb(r, g, b)
            val hex = String.format("#%02X%02X%02X", r, g, b)

            // Обновляем UI на главном потоке
            runOnUiThread {
                colorPreview.setBackgroundColor(colorInt) // Меняем цвет квадрата
                colorHexText.text = hex                  // Выводим HTML-код
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            imageProxy.close() // Обязательно закрываем ImageProxy
        }
    }

    // --- Метод фотосъемки ---
    private fun takePhoto() {
        val imageCapture = imageCapture ?: return // Проверяем, что камера инициализирована

        // Создаем файл для сохранения фото
        val photoFile = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), // Каталог DCIM
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                .format(System.currentTimeMillis()) + ".jpg" // Имя файла по дате
        )

        // Опции сохранения фото
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        // Запускаем съемку
        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this), // Главный поток
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(applicationContext, "Ошибка сохранения фото", Toast.LENGTH_SHORT)
                        .show()
                }

                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    Toast.makeText(applicationContext, "Фото сохранено: ${photoFile.name}", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        )
    }
}
