package ru.alekseychick.alekseychik_ulia_lab23

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import ru.alekseychick.alekseychik_ulia_lab23.RepoItem
import ru.alekseychick.alekseychik_ulia_lab23.RetrofitInstance

class SearchViewModel : ViewModel() {
    // livedata для наблюдения за результатами поиска
    val results = MutableLiveData<List<RepoItem>>()
    // livedata для наблюдения за ошибками
    val error = MutableLiveData<String?>()

    // функция поиска репозиториев
    fun search(query: String) {
        viewModelScope.launch {  // запуск корутины в scope viewmodel
            try {
                // выполнение сетевого запроса
                val response = RetrofitInstance.api.searchRepositories(query)
                // публикация результатов в livedata
                results.postValue(response.items)
                error.postValue(null)  // очистка ошибок при успешном запросе
            } catch (e: Exception) {
                // обработка ошибок
                results.postValue(emptyList())
                error.postValue(e.localizedMessage ?: "ошибка запроса")
            }
        }
    }
}