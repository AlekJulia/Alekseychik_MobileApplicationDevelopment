package ru.alekseychick.alekseychik_ulia_lab23

// Модель полного ответа от GitHub
// items - массив репозиториев
data class RepoResponse(
    val items: List<RepoItem>
)