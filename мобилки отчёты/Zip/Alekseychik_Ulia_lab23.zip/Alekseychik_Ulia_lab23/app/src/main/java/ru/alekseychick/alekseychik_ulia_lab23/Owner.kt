package ru.alekseychick.alekseychik_ulia_lab23

// Модель владельца репозитория, соответствует полю owner в json от GitHub
data class Owner(
    val login: String,
    val html_url: String
)

