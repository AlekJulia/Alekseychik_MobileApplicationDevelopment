package ru.alekseychick.alekseychik_ulia_lab23

import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ru.alekseychick.alekseychik_ulia_lab23.RepoItem
import ru.alekseychick.alekseychik_ulia_lab23.RepoAdapter


class MainActivity : AppCompatActivity() {

    // ViewModel — содержит всю логику запроса к API
    private val viewModel: SearchViewModel by viewModels()

    // Элементы интерфейса
    private lateinit var etQuery: EditText
    private lateinit var btnSearch: Button
    private lateinit var rvResults: RecyclerView

    // адаптер для списка репозиториев
    private lateinit var adapter: RepoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // инициализация UI-элементов
        etQuery = findViewById(R.id.etQuery)
        btnSearch = findViewById(R.id.btnSearch)
        rvResults = findViewById(R.id.rvResults)

        // инициализация адаптера (передаём пустой список в начале)
        adapter = RepoAdapter(applicationContext, emptyList())

        // Настраиваем RecyclerView — вертикальный список
        rvResults.layoutManager = LinearLayoutManager(this)
        rvResults.adapter = adapter

        // кнопка поиск запускает поиск
        btnSearch.setOnClickListener {
            val query = etQuery.text.toString().trim()
            if (query.isNotEmpty()) {
                doSearch(query)
            } else {
                Toast.makeText(this, getString(R.string.hint_search), Toast.LENGTH_SHORT).show()
            }
        }

        // Обработка нажатия клавиши поиск на клавиатуре
        etQuery.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val query = etQuery.text.toString().trim()
                if (query.isNotEmpty()) {
                    doSearch(query)
                }
                true
            } else false
        }

        // подписка на результаты из ViewModel
        viewModel.results.observe(this) { list ->
            onResultsReceived(list)
        }

        // подписка на возможные ошибки
        viewModel.error.observe(this) { errorMsg ->
            errorMsg?.let {
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun doSearch(query: String) {
        viewModel.search(query)
        Toast.makeText(this, getString(R.string.btn_search) + ": " + query, Toast.LENGTH_SHORT).show()
    }


    private fun onResultsReceived(list: List<RepoItem>) {
        if (list.isEmpty()) {
            Toast.makeText(this, getString(R.string.no_results), Toast.LENGTH_SHORT).show()
        }
        adapter.updateData(list)
    }
}