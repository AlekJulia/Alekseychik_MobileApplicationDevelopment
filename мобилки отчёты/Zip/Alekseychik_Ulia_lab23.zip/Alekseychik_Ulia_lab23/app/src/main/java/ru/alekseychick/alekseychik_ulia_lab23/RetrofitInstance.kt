package ru.alekseychick.alekseychik_ulia_lab23

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


object RetrofitInstance {
    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC  // логирование HTTP-запросов
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(logging)  // добавление интерцептора для логирования
        .build()

    // создание экземпляра Retrofit с базовым URL и конвертером Gson
    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.github.com/")  // базовый URL GitHub API
            .addConverterFactory(GsonConverterFactory.create())  // конвертер JSON в объекты
            .client(client)
            .build()
    }

    // инициализация API
    val api: GithubApi by lazy {
        retrofit.create(GithubApi::class.java)
    }
}