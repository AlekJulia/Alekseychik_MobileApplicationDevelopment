package ru.alekseychick.alekseychik_ulia_lab23

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import ru.alekseychick.alekseychik_ulia_lab23.R
import ru.alekseychick.alekseychik_ulia_lab23.RepoItem

class RepoAdapter(private val context: Context, private var list: List<RepoItem>) :
    RecyclerView.Adapter<RepoAdapter.VH>() {

    // viewholder для кэширования view-компонентов
    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tvName)
        val tvOwner: TextView = itemView.findViewById(R.id.tvOwner)
        val tvLanguage: TextView = itemView.findViewById(R.id.tvLanguage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        // создание нового viewholder при необходимости
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_repo, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val repo = list[position]

        // установка данных в view-компоненты
        holder.tvName.text = context.getString(R.string.repo_name, repo.name)
        holder.tvOwner.text = context.getString(R.string.repo_owner, repo.owner.login)
        holder.tvLanguage.text = context.getString(R.string.repo_lang, repo.language ?: "—")

        // обработчики кликов для открытия url
        holder.tvName.setOnClickListener {
            openUrl(repo.html_url)  // открытие репозитория
        }
        holder.tvOwner.setOnClickListener {
            openUrl(repo.owner.html_url)  // открытие профиля владельца
        }
    }

    // обновление данных адаптера
    fun updateData(newList: List<RepoItem>) {
        list = newList
        notifyDataSetChanged()  // уведомление об изменении данных
    }

    // открытие url в браузере
    private fun openUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    override fun getItemCount(): Int = list.size
}
