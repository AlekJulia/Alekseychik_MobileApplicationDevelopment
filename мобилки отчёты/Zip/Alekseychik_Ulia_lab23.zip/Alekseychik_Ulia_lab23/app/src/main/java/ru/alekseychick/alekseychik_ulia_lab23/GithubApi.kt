package ru.alekseychick.alekseychik_ulia_lab23

import retrofit2.http.GET
import retrofit2.http.Query
import ru.alekseychick.alekseychik_ulia_lab23.RepoResponse


interface GithubApi {
    // Запрос к: https://api.github.com/search/repositories?q=<запрос>
    @GET("search/repositories")
    suspend fun searchRepositories(
        @Query("q") query: String
    ): RepoResponse
}