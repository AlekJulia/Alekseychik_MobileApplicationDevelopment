package ru.polinazherdeva.lr20

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput

// Вспомогательный класс для создания и показа уведомлений
class NotificationHelper(private val context: Context) {

    companion object {
        // ID канала уведомлений (уникальный идентификатор канала)
        const val CHANNEL_ID = "lab20_channel_color"
        // ID самого уведомления (по нему можно обновлять или удалять уведомление)
        const val NOTIFICATION_ID = 1
    }

    // Функция для создания и показа уведомления
    fun showNotification() {
        createNotificationChannel() // Создаём канал

        // Intent для открытия MainActivity при нажатии на уведомлени
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            // Флаги очищают стек активностей и запускают новое окно приложения
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        // Готовый Intent, который будет выполнен системой при нажатии на уведомление
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE // Нельзя менять содержимое Intent позже
        )

        // Intent для кнопки "Сбросить цвет"
        val resetIntent = Intent(context, NotificationReceiver::class.java).apply {
            action = NotificationReceiver.ACTION_RESET_COLOR // Задаём действие
        }
        // PendingIntent, который будет отправлен BroadcastReceiver при нажатии кнопки
        val resetPendingIntent = PendingIntent.getBroadcast(
            context, 1, resetIntent, PendingIntent.FLAG_IMMUTABLE
        )

        // Создаём поле для ввода текста (HEX-кода цвета)
        val remoteInput = RemoteInput.Builder(NotificationReceiver.KEY_TEXT)
            .setLabel(context.getString(R.string.label_input_color)) // Подпись поля ввода
            .build()

        // Intent для кнопки "Задать цвет"
        val setColorIntent = Intent(context, NotificationReceiver::class.java).apply {
            action = NotificationReceiver.ACTION_SET_COLOR
        }
        // PendingIntent для действия "Задать цвет" (должен быть MUTABLE, чтобы можно было передать введённый текст)
        val setColorPendingIntent = PendingIntent.getBroadcast(
            context, 2, setColorIntent, PendingIntent.FLAG_MUTABLE
        )

        // Создаём действие для уведомления с полем ввода
        val setColorAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_edit, // Иконка кнопки
            context.getString(R.string.action_set_color), // Текст кнопки
            setColorPendingIntent // Действие по нажатию
        ).addRemoteInput(remoteInput) // Добавление текстового поля ввола
            .build()

        // Конструктор уведомления
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_art) //  значок
            .setContentTitle(context.getString(R.string.title_notification)) // Заголовок
            .setContentText(context.getString(R.string.text_notification)) // Основной текст
            .setPriority(NotificationCompat.PRIORITY_HIGH) // Всплывающее
            .setCategory(Notification.CATEGORY_MESSAGE) // Категория — сообщение
            .setAutoCancel(true) // Уведомление исчезнет после нажатия
            .setContentIntent(openAppPendingIntent) // Действие при нажатии на уведомление
            // Добавляем кнопку "Сбросить цвет"
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                context.getString(R.string.action_reset_color),
                resetPendingIntent
            )
            // Добавляем кнопку "Задать цвет" с возможностью ввода
            .addAction(setColorAction)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC) // Делаем уведомление видимым даже на экране блокировки

        try {
            // Показываем уведомление
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, builder.build())
        } catch (e: SecurityException) {
            e.printStackTrace() // Если нет разрешения POST_NOTIFICATIONS, получаем исключение
        }
    }

    // Создание канала уведомлений с высоким приоритетом
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Имя и описание канала берём из ресурсов
            val name = context.getString(R.string.title_notification)
            val descriptionText = context.getString(R.string.text_notification)
            val importance = NotificationManager.IMPORTANCE_HIGH // Высокая важность
            // Создаём объект канала
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true) // Включаем вибрацию
                enableLights(true) // Включаем мигание индикатора
                lightColor = Color.MAGENTA // Цвет индикатора
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC // Видимость на экране блокировки
            }

            // Регистрируем канал в системе
            val manager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
