package ru.polinazherdeva.lr20

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// Приёмник, который обрабатывает действия из уведомления
class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // Запускаем корутину для безопасной обработки событий
        CoroutineScope(Dispatchers.Default).launch {
            when (intent.action) {
                // Если нажата кнопка "Сбросить" → отправляем событие EventBus
                ACTION_RESET_COLOR -> EventBus.sendEvent(ACTION_RESET_COLOR)
                // Если введён цвет → считываем его и отправляем
                ACTION_SET_COLOR -> {
                    val results = RemoteInput.getResultsFromIntent(intent)
                    val colorText = results?.getCharSequence(KEY_TEXT)?.toString()
                    if (colorText != null) {
                        lastColor = "#$colorText" // Сохраняем введённый цвет
                        EventBus.sendEvent(ACTION_SET_COLOR) // Отправляем событие в EventBus
                    }
                }
            }
        }
    }

    companion object {
        // Константы для идентификации действий
        const val ACTION_RESET_COLOR = "ru.polinazherdeva.lr20.RESET_COLOR"
        const val ACTION_SET_COLOR = "ru.polinazherdeva.lr20.SET_COLOR"
        const val KEY_TEXT = "key_text_reply" // Ключ для поля ввода
        var lastColor: String? = null // Хранит последний введённый цвет
    }
}
