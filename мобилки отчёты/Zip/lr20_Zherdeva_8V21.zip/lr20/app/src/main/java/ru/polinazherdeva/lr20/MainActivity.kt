package ru.polinazherdeva.lr20

import android.Manifest
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var rootLayout: LinearLayout
    private lateinit var colorText: TextView
    private lateinit var notificationHelper: NotificationHelper

    // Лаунчер для запроса разрешения на уведомления
    private val requestPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) showNotification() // Разрешение получено → показываем уведомление
            else Toast.makeText(this, getString(R.string.toast_no_permission), Toast.LENGTH_SHORT).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Подключаем макет

        // Находим элементы из разметки
        rootLayout = findViewById(R.id.rootLayout)
        colorText = findViewById(R.id.colorText)
        notificationHelper = NotificationHelper(this)

        // Настраиваем кнопку для вызова уведомления
        findViewById<Button>(R.id.btnShowNotification).apply {
            text = getString(R.string.text_show_notification)
            setOnClickListener { handleNotificationRequest()  }  // Обработчик нажатия
        }

        // Подписываемся на события из EventBus
        lifecycleScope.launch {
            EventBus.events.collectLatest { action ->
                when (action) {
                    // Если пришло событие "сбросить цвет" — ставим белый фон
                    NotificationReceiver.ACTION_RESET_COLOR -> setColor("#FFFFFF")
                    // Если пришло "установить цвет" — применяем последний введённый цвет
                    NotificationReceiver.ACTION_SET_COLOR -> {
                        val color = NotificationReceiver.lastColor ?: "#FFFFFF"
                        setColor(color)
                    }
                }
            }
        }
    }

    // Проверка разрешения и показ уведомления
    private fun handleNotificationRequest() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                // Если разрешения нет — запрашиваем его
                requestPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else showNotification() // Разрешение есть — показываем уведомление
        } else showNotification() // Для старых версий Android
    }


    // Показ уведомления через вспомогательный класс
    private fun showNotification() = notificationHelper.showNotification()

    // Изменение цвета фона и текста на экране
    private fun setColor(hex: String) {
        try {
            val parsed = Color.parseColor(hex) // Парсим строку в цвет
            rootLayout.setBackgroundColor(parsed) // Меняем цвет фона
            colorText.text = getString(R.string.text_selected_color, hex) // Обновляем текст
        } catch (e: Exception) {
            // Если пользователь ввёл неверный цветовой код
            Toast.makeText(this, getString(R.string.toast_invalid_color), Toast.LENGTH_SHORT).show()
        }
    }
}