package ru.polinazherdeva.lr20

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

// Создаём объект (Singleton), который будет служить шиной событий (EventBus)
object EventBus {
    private val _events = MutableSharedFlow<String>() // Создаём изменяемый поток данных, в который можно отправлять события
    val events = _events.asSharedFlow() // Делаем неизменяемую публичную версию потока, чтобы другие классы могли только слушать события

    // suspend-функция для отправки события (выполняется в корутине)
    suspend fun sendEvent(action: String) {
        _events.emit(action)  // Отправляем событие всем подписчикам
    }
}