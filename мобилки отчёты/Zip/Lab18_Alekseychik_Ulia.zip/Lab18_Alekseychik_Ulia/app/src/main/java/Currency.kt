package ru.alekseychick.lab18

data class Currency(
    val charCode: String,   // трехбуквенный код (USD, EUR ...)
    val name: String,       // полное название валюты
    val nominal: Int,       // номинал (обычно 1, но может быть 10/100)
    val value: Double       // значение в рублях (число, например 74.1234)
)