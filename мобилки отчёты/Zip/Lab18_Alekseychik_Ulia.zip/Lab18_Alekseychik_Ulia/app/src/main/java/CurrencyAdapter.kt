package ru.alekseychick.lab18

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

// Простой RecyclerView.Adapter для списка Currency
class CurrencyAdapter : RecyclerView.Adapter<CurrencyAdapter.VH>() {

    // Внутренний список элементов; изначально пуст
    private var items: List<Currency> = emptyList()

    // Установить новые данные и обновить список
    fun setItems(newItems: List<Currency>) {
        items = newItems
        notifyDataSetChanged() // простая реализация; для больших списков лучше DiffUtil
    }

    // ViewHolder — хранит ссылки на View одного элемента
    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCode: TextView = itemView.findViewById(R.id.tv_code)
        val tvName: TextView = itemView.findViewById(R.id.tv_name)
        val tvValue: TextView = itemView.findViewById(R.id.tv_value)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        // Создаём View для элемента, надувая layout item_currency.xml
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_currency, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        // Приводим данные к View
        val item = items[position]
        holder.tvCode.text = item.charCode            // USD
        holder.tvName.text = item.name               // Доллар США
        // Формируем строку "N = X.XXXX", где N — номинал, X — значение (4 знака)
        holder.tvValue.text = String.format(Locale.US, "%d = %.4f", item.nominal, item.value)
    }

    override fun getItemCount(): Int = items.size
}