package ru.alekseychick.lab18

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.net.URL
import java.nio.charset.Charset

class MainActivity : AppCompatActivity() {

    // UI-элементы
    private lateinit var btnFetch: Button
    private lateinit var progress: ProgressBar
    private lateinit var recycler: RecyclerView

    // Адаптер для RecyclerView
    private val adapter = CurrencyAdapter()

    // Job текущей загрузки (если нужно отменить)
    private var fetchJob: Job? = null

    // URL для загрузки XML от ЦБ
    private val cbrUrl = "https://www.cbr.ru/scripts/XML_daily.asp"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Связываем Activity с layout
        setContentView(R.layout.activity_main)

        // Находим View по id из layout
        btnFetch = findViewById(R.id.btn_fetch)
        progress = findViewById(R.id.progress)
        recycler = findViewById(R.id.recycler)

        // Настраиваем RecyclerView: вертикальный список и наш адаптер
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        // Нажатие на кнопку — запускает загрузку
        btnFetch.setOnClickListener {
            startFetch()
        }
    }

    // Запускает процесс загрузки — безопасно, через корутину
    private fun startFetch() {
        // Если уже идёт загрузка — не запускаем новую
        if (fetchJob != null) return

        // Показываем прогрессбар и скрываем список (чтобы видно было, что идёт загрузка)
        progress.visibility = View.VISIBLE
        recycler.visibility = View.GONE

        // Очищаем старые данные
        adapter.setItems(emptyList())

        // Запускаем корутину, связанная с lifecycle (отменится при destroy)
        fetchJob = lifecycleScope.launch {
            try {
                // Выполняем сетевой вызов в IO-потоке — чтобы не блокировать UI
                val xml: String = withContext(Dispatchers.IO) {
                    // URL.readText считывает содержимое в String.
                    // Указываем кодировку Windows-1251, как требует задание.
                    URL(cbrUrl).readText(Charset.forName("Windows-1251"))
                }

                // Парсим XML (парсинг — быстрый, можно сделать в IO тоже)
                val list = withContext(Dispatchers.Default) {
                    parseCurrencies(xml)
                }

                // Обновляем UI на главном потоке: показываем список и скрываем прогресс
                withContext(Dispatchers.Main) {
                    if (list.isEmpty()) {
                        Toast.makeText(this@MainActivity, "Не удалось получить данные", Toast.LENGTH_SHORT).show()
                    }
                    adapter.setItems(list)
                    progress.visibility = View.GONE
                    recycler.visibility = View.VISIBLE
                }
            } catch (e: Exception) {
                // В случае ошибок (сеть, парсинг и т.д.) уведомляем пользователя
                withContext(Dispatchers.Main) {
                    progress.visibility = View.GONE
                    recycler.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                // Очистим Job — чтобы можно было запустить следующую загрузку
                fetchJob = null
            }
        }
    }

    /**
     * parseCurrencies — функция, которая принимает XML в виде строки
     * и возвращает список объектов Currency, найденных в документе.
     *
     * Для парсинга используется XmlPullParser (стандартный парсер Android).
     */
    private fun parseCurrencies(xml: String): List<Currency> {
        // Подготовим результат
        val list = mutableListOf<Currency>()

        // Создаём парсер (фабрика)
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()

        // Передаём парсеру строковый источник — StringReader
        parser.setInput(StringReader(xml))

        // Переменные для временного хранения данных текущего <Valute> элемента
        var currentCode: String? = null
        var currentName: String? = null
        var currentNominal: Int = 1
        var currentValueStr: String? = null

        // Тип текущего события (startTag, text, endTag и т.д.)
        var eventType = parser.eventType

        // Проходим документ, пока не наступит END_DOCUMENT
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    // Если встретили открывающий тег
                    when (parser.name) {
                        "Valute" -> {
                            // Начали новый элемент валюты — обнуляем временные поля
                            currentCode = null
                            currentName = null
                            currentNominal = 1
                            currentValueStr = null
                        }
                        "CharCode" -> {
                            // Следующий event будет TEXT — читаем его
                            parser.next()
                            currentCode = parser.text
                        }
                        "Name" -> {
                            parser.next()
                            currentName = parser.text
                        }
                        "Nominal" -> {
                            parser.next()
                            // Попробуем распарсить в Int, если не получится — оставим 1
                            currentNominal = parser.text?.toIntOrNull() ?: 1
                        }
                        "Value" -> {
                            parser.next()
                            // Значение приходит в виде "62,3530" — запомним строку
                            currentValueStr = parser.text
                        }
                    }
                }

                XmlPullParser.END_TAG -> {
                    // Если встретили закрывающий тег
                    if (parser.name == "Valute") {
                        // Собираем объект Currency и добавляем в список
                        // Преобразуем строку значения в Double — заменим запятую на точку
                        val valueDouble = currentValueStr
                            ?.replace(',', '.')
                            ?.toDoubleOrNull() ?: 0.0

                        // Если код или имя отсутствуют — пропустим
                        if (!currentCode.isNullOrBlank() && !currentName.isNullOrBlank()) {
                            val currency = Currency(
                                charCode = currentCode,
                                name = currentName,
                                nominal = currentNominal,
                                value = valueDouble
                            )
                            list.add(currency)
                        }
                    }
                }
            }
            // Переходим к следующему событию
            eventType = parser.next()
        }

        return list
    }

    override fun onDestroy() {
        super.onDestroy()
        // Если Activity уничтожается, отменяем возможную корутину загрузки
        fetchJob?.cancel()
    }
}