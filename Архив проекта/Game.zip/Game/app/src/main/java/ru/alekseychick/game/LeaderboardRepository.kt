package ru.alekseychick.game

import android.util.Log
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import ru.alekseychick.game.AppDatabase
import ru.alekseychick.game.RemoteRecord
import ru.alekseychick.game.ScoreDao
import ru.alekseychick.game.ScoreRecord
import ru.alekseychick.game.ApiService
import java.text.SimpleDateFormat
import java.util.*

// репозиторий объединяет доступ к локальным записям и загрузку remote top-5
class LeaderboardRepository(context: Context) { // cоздание репозитория, который работает и с локальной бд и с сервером

    // получение доступк к (singleton) dao через appDatabase для работы с бд
    private val scoreDao: ScoreDao = AppDatabase.getInstance(context).scoreDao()

    // Retrofit - библиотека для http запросов
    private val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://jsonplaceholder.typicode.com") // url для api
            .addConverterFactory(GsonConverterFactory.create()) // преобразование в json объекты
            .build() // создание экземпляра Retrofit
            .create(ApiService::class.java) // создание объекта ApiService
    }

    // получение Flow всех локальных рекордов отсортированных по убыванию очков (методы в ScoreDao)
    fun getLocalRecords(): Flow<List<ScoreRecord>> = scoreDao.getAllSortedByScoreDesc()

    // функция чтобы вставить новый локальный рекорд
    suspend fun insertLocalRecord(record: ScoreRecord): Long {
        return withContext(Dispatchers.IO) {
            scoreDao.insert(record) // вызов метода из scoreDao.kt
        }
    }

    // функция отчистки
    suspend fun clearLocal() {
        withContext(Dispatchers.IO) { scoreDao.clearAll() }
    }

    // загрузка топ-5 мировых рекордов из сети и преобразование их в RemoteRecord
    suspend fun fetchTop5Remote(): List<RemoteRecord> = withContext(Dispatchers.IO) {
        try {
            val posts = api.getPosts()
            println("Данные загружены: ${posts.size} постов")
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = sdf.format(Date())

            // преобразование 5 постов в фиктивные рекорды
            posts.take(5).map { post ->
                val pseudoScore = (post.body.length * 3 + post.id * 17) % 1000
                RemoteRecord(
                    id = post.id,
                    playerName = post.title.take(20),
                    score = pseudoScore,
                    date = date
                )
            }

        } catch (e: Exception) {
            Log.e("LeaderboardRepository", "Ошибка при загрузке: ${e.message}", e)
            emptyList() // Возвращаем пустой список, чтобы не упало приложение
        }
    }
}