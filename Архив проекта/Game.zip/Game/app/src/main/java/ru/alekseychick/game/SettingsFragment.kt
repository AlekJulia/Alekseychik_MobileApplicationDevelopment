package ru.alekseychick.game

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Switch
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider

// фрагмент настроек: сохраняет имя игрока и состояние музыки в SharedPreferences
class SettingsFragment : Fragment() {

    // элементы ui
    private lateinit var switchMusic: Switch
    private lateinit var etPlayerName: EditText

    // константы для SharedPreferences
    private val PREFS_NAME = "game_prefs"
    private val KEY_MUSIC = "pref_music"
    private val KEY_PLAYER_NAME = "pref_player_name"
    private val DEFAULT_PLAYER_NAME = "Игрок"

    private lateinit var sharedViewModel: SharedViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // создание ui из fragment_settings.xml
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedViewModel = ViewModelProvider(requireActivity()).get(SharedViewModel::class.java)

        // инициализация ui элементов, найденных в fragment_settings.xml
        switchMusic = view.findViewById(R.id.switchMusic)
        etPlayerName = view.findViewById(R.id.etPlayerName)

        // загрузка сохранённых настроек из SharedPreferences
        val prefs = requireActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val musicOn = prefs.getBoolean(KEY_MUSIC, true)
        val playerName = prefs.getString(KEY_PLAYER_NAME, DEFAULT_PLAYER_NAME) ?: DEFAULT_PLAYER_NAME

        // приминение настроек к ui элементам
        switchMusic.isChecked = musicOn
        etPlayerName.setText(playerName)

        // обработчик для переключателя музыки
        switchMusic.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean(KEY_MUSIC, isChecked).apply()
        }

        // сохранение имени при потере фокуса
        etPlayerName.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                savePlayerNameIfNeeded()
            }
        }

        // сохнранение при уходе с фрагмента
        viewLifecycleOwner.lifecycle.addObserver(androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_PAUSE) {
                savePlayerNameIfNeeded()
            }
        })

    }

    // функция для сохранения имени игрока
    private fun savePlayerNameIfNeeded() {
        val name = etPlayerName.text.toString().ifBlank { DEFAULT_PLAYER_NAME }
        val prefs = requireActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PLAYER_NAME, name).apply()
    }
}