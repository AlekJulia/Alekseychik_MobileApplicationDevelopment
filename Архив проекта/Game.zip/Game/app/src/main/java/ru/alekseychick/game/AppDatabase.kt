package ru.alekseychick.game

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

// объединение таблицы и операций над таблицей

// объявление базы данных (указываем ScoreRecord как таблицу)
@Database(entities = [ScoreRecord::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scoreDao(): ScoreDao // получаем доступ к функциям из файла ScoreDao.kt

    companion object {
        // Singleton - у класса только один экземпляр
        @Volatile // переменной для экземпляра
        private var INSTANCE: AppDatabase? = null

        // функция для получения экземпляра
        fun getInstance(context: Context): AppDatabase {
            // проверка на существование объекта и его создание
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder( // создание базы данных
                    context.applicationContext,
                    AppDatabase::class.java, // класс базы даннных
                    "game_database" // имя файл базы данных
                ).build()
                INSTANCE = instance // сохранение созданного объекта
                instance // возвращение объекта
            }
        }

    }
}