package ru.alekseychick.game

//  класс сыра
data class Cheese(
    var x: Float,
    var y: Float,
    val size: Int
)
