package ru.alekseychick.game

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ru.alekseychick.game.R
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

// фрагмент, эран таблицы лидеров
class LeaderboardFragment : Fragment() {

    // получаем viewModel и адаптеры
    private lateinit var viewModel: LeaderboardViewModel
    private lateinit var localAdapter: ScoreAdapter
    private lateinit var remoteAdapter: RemoteAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_leaderboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        viewModel = ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(requireActivity().application))
            .get(LeaderboardViewModel::class.java)

        // нахождение элементов
        val rvLocal: RecyclerView = view.findViewById(R.id.rvLocalScores)
        val rvRemote: RecyclerView = view.findViewById(R.id.rvRemoteTop)
        val btnLoad: Button = view.findViewById(R.id.btnLoadTop5)

        // настрока адаптеров
        localAdapter = ScoreAdapter()
        remoteAdapter = RemoteAdapter()

        // связывание адаптеров со списками
        rvLocal.layoutManager = LinearLayoutManager(requireContext())
        rvLocal.adapter = localAdapter

        rvRemote.layoutManager = LinearLayoutManager(requireContext())
        rvRemote.adapter = remoteAdapter

        // наблюдение за локальными рекордами через StateFlow
        lifecycleScope.launch {
            viewModel.localRecords.collectLatest { list ->
                localAdapter.submitList(list)
            }
        }

        // наблюдение за топ-5,  показываем список когда придёт
        lifecycleScope.launch {
            viewModel.remoteTop.collectLatest { list ->
                if (list.isEmpty()) {
                    rvRemote.visibility = View.GONE

                } else {
                    rvRemote.visibility = View.VISIBLE // показывается, если есть данные
                    remoteAdapter.submitList(list)
                }
            }
        }

        // обработка кнопки
        btnLoad.setOnClickListener {
            // загрузка данных
            viewModel.loadTop5()
            Toast.makeText(requireContext(), "Загрузка топ-5...", Toast.LENGTH_SHORT).show() // показваем сообщение в окошке для загрузки данных
        }
    }
}