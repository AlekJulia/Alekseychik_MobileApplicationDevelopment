package ru.alekseychick.game

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

// постоянное уведомление для счета
class GameForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "game_channel" // ID канала уведомлений
        const val NOTIF_ID = 0x1234 // ID уведомления
        const val ACTION_UPDATE = "ru.alekseychick.game.ACTION_UPDATE_SCORE"
    }

    // создание канала уведомлений
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(CHANNEL_ID, "Game", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(chan)
        }
    }

    // запуск сервера
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val score = intent?.getIntExtra("score", 0) ?: 0
        val notif = createNotification(score)
        startForeground(NOTIF_ID, notif)
        return START_STICKY
    }

    // создание уведомления
    private fun createNotification(score: Int): Notification {
        val builder = androidx.core.app.NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Кошки-Мышки — игра")
            .setContentText("Текущий счет: $score")
            .setOngoing(true)
        return builder.build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
