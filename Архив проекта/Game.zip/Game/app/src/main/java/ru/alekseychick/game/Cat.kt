package ru.alekseychick.game

data class Cat(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val size: Int
)
