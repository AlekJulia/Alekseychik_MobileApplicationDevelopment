package ru.alekseychick.game

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Адаптер для RecyclerView списка уровней
class LevelsAdapter(
    private val items: List<Level>, // список данных для отображения
    private val onItemClick: (Level) -> Unit // колбэк функция при клике на элемент
) : RecyclerView.Adapter<LevelsAdapter.LevelViewHolder>() { // адаптер наследуется от RecyclerView.Adapter

    // вложенный класс, который содержит ссылки на элементы ui
    inner class LevelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tvLevelName)
        val tvDifficulty: TextView = itemView.findViewById(R.id.tvLevelDifficulty)
    }

    // Создает новые экземпляры ViewHolder (элемент списка)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LevelViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_level, parent, false)
        return LevelViewHolder(view)
    }

    // RecyclerView вызывает метод onBindViewHolder, чтобы обновить содержимое ViewHolder для определенной позиции
    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {
        // получение объекта Level для текущей позиции в списке данных items
        val level = items[position]

        // заполнение TextViews в ViewHolder данными из объекта Level
        holder.tvName.text = level.name
        holder.tvDifficulty.text = level.difficulty

        // при клике вызывается переданный колбэк
        holder.itemView.setOnClickListener {
            onItemClick(level)
        }
    }

    // возвращение общего количества элементов в списке
    // RecyclerView использует это, чтобы знать, сколько строк ему нужно отобразить
    override fun getItemCount(): Int = items.size
}