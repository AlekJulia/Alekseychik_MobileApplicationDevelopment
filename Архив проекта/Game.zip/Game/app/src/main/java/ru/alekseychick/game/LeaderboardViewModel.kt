package ru.alekseychick.game

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ru.alekseychick.game.ScoreRecord
import ru.alekseychick.game.RemoteRecord
import ru.alekseychick.game.LeaderboardRepository
import kotlinx.coroutines.flow.map

// файл посредник между ui и данными repository
// ViewModel для Leaderboard, используем AndroidViewModel чтобы получить context для репозитория

class LeaderboardViewModel(application: Application) : AndroidViewModel(application) {

    // инициализация репозитория
    private val repo = LeaderboardRepository(application.applicationContext)

    // Flow локальных рекордов, превращаем в StateFlow, который хранит текущее состояние
    val localRecords: StateFlow<List<ScoreRecord>> = repo.getLocalRecords()
        .catch { emit(emptyList()) } // на случай ошибок
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // мировые рекорды Топ-5
    private val _remoteTop = kotlinx.coroutines.flow.MutableStateFlow<List<RemoteRecord>>(emptyList())
    val remoteTop: StateFlow<List<RemoteRecord>> = _remoteTop

    // загрузка топ-5 рекордов
    fun loadTop5() {
        viewModelScope.launch {
            try {
                val top = repo.fetchTop5Remote() // загрузка данных с сервера через репозиторий
                _remoteTop.value = top
            } catch (e: Exception) {
                // Обработка ошибки (логирование/уведомление). Оставим пустой топ при ошибке
                _remoteTop.value = emptyList()
            }
        }
    }

    // вставка тестового рекорда
    fun addSampleRecord(player: String, score: Int) {
        viewModelScope.launch {
            val date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
            repo.insertLocalRecord(ScoreRecord(playerName = player, score = score, date = date))
        }
    }

    // отчистка всех рекордов
    fun clearLocal() {
        viewModelScope.launch { repo.clearLocal() }
    }
}