package ru.alekseychick.game

// класс для мыши
data class Mouse(
    val name: String = "", // имя
    val speed: Int // скорость мыши
) {
    fun getMouseInfo(): String { // отображение информации о мыши
        return "Мышь по имени $name бежит со скоростью $speed"
    }
}