package ru.alekseychick.game

import org.junit.Assert.assertEquals
import org.junit.Test

class MouseTest {
// юнит тест для проверки корректности работы функции
    @Test
    fun testGetMouseInfo_withNameAndSpeed_returnsCorrectString() {
        val mouse = Mouse(name = "Джерри", speed = 5)
        val expected = "Мышь по имени Джерри бежит со скоростью 5"
        assertEquals(expected, mouse.getMouseInfo())
    }

    @Test
    fun testGetMouseInfo_defaultName_returnsEmptyNameInString() {
        val mouse = Mouse(speed = 3) // name по умолчанию ""
        val expected = "Мышь по имени  бежит со скоростью 3"
        assertEquals(expected, mouse.getMouseInfo())
    }
}