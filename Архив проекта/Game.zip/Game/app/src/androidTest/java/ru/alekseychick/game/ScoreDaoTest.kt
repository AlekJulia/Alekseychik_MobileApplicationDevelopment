package ru.alekseychick.game

import androidx.room.Room
import kotlinx.coroutines.flow.first
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ScoreDaoTest {

    private lateinit var database: AppDatabase
    private lateinit var dao: ScoreDao

    @Before
    fun setup() {
        database = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            AppDatabase::class.java
        ).build()
        dao = database.scoreDao()
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun insertAndRetrieveRecord() = runBlocking {
        // Вставляем запись
        val record = ScoreRecord(playerName = "Test", score = 100, date = "2024-01-15")
        dao.insert(record)

        // Проверяем что запись есть в базе
        val records = dao.getAllSortedByScoreDesc().first()
        assert(records.isNotEmpty())
    }

    @Test
    fun clearAllRecords() = runBlocking {
        // Добавляем запись и очищаем
        val record = ScoreRecord(playerName = "Test", score = 100, date = "2024-01-15")
        dao.insert(record)
        dao.clearAll()

        // Проверяем что база пустая
        val records = dao.getAllSortedByScoreDesc().first()
        assert(records.isEmpty())
    }
}