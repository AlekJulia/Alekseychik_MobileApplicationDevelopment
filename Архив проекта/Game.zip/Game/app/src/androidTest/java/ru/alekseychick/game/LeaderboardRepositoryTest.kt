package ru.alekseychick.game

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LeaderboardRepositoryTest {

    @Test
    fun insertAndGetLocalRecords() = runBlocking {
        val repository = LeaderboardRepository(ApplicationProvider.getApplicationContext())

        // Вставляем запись
        val record = ScoreRecord(playerName = "Test", score = 200, date = "2024-01-15")
        repository.insertLocalRecord(record)

        // Проверяем что можем получить записи
        val records = repository.getLocalRecords().first()
        assert(records.isNotEmpty())
    }

    @Test
    fun fetchRemoteRecords() = runBlocking {
        val repository = LeaderboardRepository(ApplicationProvider.getApplicationContext())

        // Пробуем загрузить данные с сервера
        val remoteRecords = repository.fetchTop5Remote()

        // Проверяем что функция работает (не падает)
        assert(remoteRecords != null)
    }
}